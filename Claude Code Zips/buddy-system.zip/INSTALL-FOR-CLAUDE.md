# Buddy Collection System — Claude Code Install Prompt

Copy everything below and paste it to Claude Code to set up the buddy system.

---

## Prompt

Install the buddy collection system from `buddy-system/buddy.js`. Here's what to do:

1. **Ensure Node.js is installed** (v18+). If not, install it via homebrew: `brew install node`

2. **Copy buddy.js** to `~/Claude/buddy-system/buddy.js`:
   ```bash
   mkdir -p ~/Claude/buddy-system
   cp buddy.js ~/Claude/buddy-system/buddy.js
   ```

3. **Create the `buddy` command** by writing this wrapper script to `~/.local/bin/buddy`:
   ```bash
   #!/bin/bash
   exec node ~/Claude/buddy-system/buddy.js "$@"
   ```
   Then make it executable: `chmod +x ~/.local/bin/buddy`

4. **Create the `slaughter` shortcut** at `~/.local/bin/slaughter`:
   ```bash
   #!/bin/bash
   exec buddy slaughter "$@"
   ```
   Then: `chmod +x ~/.local/bin/slaughter`

5. **Get your first buddy** by using the `/buddy` command in Claude Code (the rainbow text in the footer). This creates your companion through Claude Code's built-in system.

6. **Verify it works** by running: `buddy help`

Commands:

```
! buddy stats              — show active buddy + stats
! buddy index              — collection grid (discovered/undiscovered/slaughtered)
! buddy log                — full collection + catalogue view
! buddy catalogue          — browse all 18 species
! buddy equip eyes <style> — change eyes (dot/sparkle/cross/circle/at/degree)
! buddy equip hat <type>   — change hat (crown/tophat/propeller/halo/wizard/beanie/tinyduck/none)
! buddy claim              — pick up dropped eggs
! buddy hatch              — hatch an egg into a new buddy
! buddy rename <name>      — rename active buddy (costs 1 rename point)
! buddy slaughter <name>   — kill any buddy for +1 rename point (animated)
! buddy switch <name>      — switch active buddy
! buddy release <name>     — release a buddy
! buddy help               — show all commands
```

The buddy.js file should be at `~/Claude/buddy-system/buddy.js`. If you have no buddies, the rainbow `/buddy` appears in the footer — use it to get started.
