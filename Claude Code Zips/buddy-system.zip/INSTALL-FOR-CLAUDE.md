# Buddy Collection System — Claude Code Install Prompt

Copy everything below and paste it to Claude Code to set up the buddy system.

---

## Prompt

Install the buddy collection system from `buddy-system/buddy.js`. Here's what to do:

1. **Ensure Node.js is installed** (v18+). If not, install it via homebrew: `brew install node`

2. **Create the `buddy` command** by writing this wrapper script to `~/.local/bin/buddy`:
   ```bash
   #!/bin/bash
   exec node ~/Claude/buddy-system/buddy.js "$@"
   ```
   Then make it executable: `chmod +x ~/.local/bin/buddy`

3. **Verify it works** by running: `buddy help`

4. **Initialize my collection** by running: `buddy stats`

That's it. From now on I can use these commands with `!` in Claude Code:

```
! buddy stats              — show my active buddy + stats
! buddy equip              — list my buddies to equip
! buddy equip <name>       — equip a specific buddy
! buddy equip eyes <style> — change eyes (dot/sparkle/cross/circle/at/degree)
! buddy equip hat <type>   — change hat (crown/tophat/propeller/halo/wizard/beanie/tinyduck/none)
! buddy equip name <name>  — rename active buddy
! buddy index              — collection grid
! buddy log                — full collection + catalogue view
! buddy catalogue          — browse all 18 species
! buddy claim              — pick up dropped eggs
! buddy hatch              — hatch an egg into a new buddy
! buddy release <name>     — release a buddy
! buddy help               — show all commands
```

The buddy.js file is already at `~/Claude/buddy-system/buddy.js` — just set up the wrapper and you're good.
