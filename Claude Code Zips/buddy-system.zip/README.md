# Buddy Collection System

A companion collection game for Claude Code. Hatch eggs, collect all 18 species, customize eyes and hats, and build your buddy roster.

## Install

Requires **Node.js >= 18**.

```bash
# Clone or copy buddy-system/ somewhere
# Then create a wrapper script on your PATH:

cat > ~/.local/bin/buddy << 'EOF'
#!/bin/bash
exec node /path/to/buddy-system/buddy.js "$@"
EOF
chmod +x ~/.local/bin/buddy
```

Replace `/path/to/buddy-system/` with the actual path to `buddy.js`.

In Claude Code, run commands with the `!` prefix:
```
! buddy stats
! buddy equip
```

## Commands

| Command | Description |
|---|---|
| `buddy stats` | Show your active buddy with ASCII art, stat bars, and egg status |
| `buddy index` | View your collection grid — shows discovered and undiscovered species |
| `buddy log` | Full view: collection details + catalogue + customization reference |
| `buddy catalogue` | Browse all 18 species, eyes, hats, and rarities |
| `buddy equip` | Show all your buddies and which one is equipped |
| `buddy equip <name>` | Equip (switch to) a buddy — only one active at a time |
| `buddy equip eyes <style>` | Change eyes on your active buddy |
| `buddy equip hat <type>` | Change hat on your active buddy |
| `buddy claim` | Pick up any eggs your buddy has dropped |
| `buddy hatch` | Hatch a claimed egg into a new random buddy |
| `buddy rename <name>` | Rename active buddy (costs 1 rename point) |
| `buddy slaughter <name>` | Kill any buddy for +1 rename point (animated) |
| `buddy switch <name>` | Switch active buddy (same as `equip <name>`) |
| `buddy release <name>` | Release a buddy from your collection |
| `buddy help` | Show command reference |

## Egg System

Your active buddy drops eggs over time. Check `buddy stats` periodically to trigger drops.

Egg drop speed depends on your buddy's rarity:
- **Common**: 30s -- 1.2 min
- **Uncommon**: 40s -- 1m 50s
- **Rare**: 1 -- 3 min
- **Epic**: 2 -- 5 min
- **Legendary**: 5 -- 10 min

Rarer buddies also drop rarer eggs. Common buddies can never drop legendary or epic eggs.

Buddies age with active coding time (1 year = 10 min, max 10 years). Each year speeds up egg drops by 10%.

Workflow:
1. `buddy stats` — triggers egg check, shows if one dropped
2. `buddy claim` — picks up unclaimed eggs
3. `buddy hatch` — hatches a claimed egg into a random new buddy

**Duplicates:** If you hatch a species you already own, it wanders off and doesn't get added to your collection. The system biases against already-owned and previously-slaughtered species, so rarer species become more likely as your collection grows.

## Species (18 total)

```
duck        goose       blob        cat         dragon      octopus
    __        (%>       .----.      /\_/\      /^\  /^\     .----.
  <(% )___     ||      ( %  % )   ( %   %)   <  %  %  >   ( %  % )
   (  ._>    _(__)_    (      )   (  w  )    (   ~~   )   (______)
    `--'      ^^^^      `----'    (")_(")     `-vvvv-'    /\/\/\/\

owl         penguin     turtle      snail       ghost       axolotl
   /\  /\    .---.       _,--._         .--.     .----.   }~(______)~{
  ((%)(%)   (%>%)      ( %  % )   \  ( % )   / %  % \   }~(% .. %)~{
  (  ><  )  /(   )\   /[______]\   \_`--'    |      |     ( .--. )
   `----'    `---'     ``    ``   ~~~~~~~    ~`~``~`~     (_/  \_)

capybara    cactus      robot       rabbit      mushroom    chonk
  n______n   n  ____  n    .[||].     (\__/)    .-o-OO-o-.   /\    /\
 ( %    % )  | |%  %| |  [ %  % ]   ( %  % )  (__________)  ( %    % )
 (   oo   )  |_|    |_|  [ ==== ]  =(  ..  )=    |%  %|     (   ..   )
  `------'     |    |     `------'   (")__(")     |____|      `------'
```

(% = eye position, replaced with your buddy's eye style)

## Customization

### Eyes
| Name | Character |
|---|---|
| dot | `·` |
| sparkle | `✦` |
| cross | `×` |
| circle | `◉` |
| at | `@` |
| degree | `°` |

### Hats (uncommon+ rarity, or equip manually)
| Name | Art |
|---|---|
| crown | `\^^^/` |
| tophat | `[___]` |
| propeller | `-+-` |
| halo | `(   )` |
| wizard | `/^\` |
| beanie | `(___)` |
| tinyduck | `,>` |

### Rarities
| Rarity | Stars | Hatch odds | Stat floor |
|---|---|---|---|
| Common | ★ | 60% | 5 |
| Uncommon | ★★ | 25% | 15 |
| Rare | ★★★ | 10% | 25 |
| Epic | ★★★★ | 4% | 35 |
| Legendary | ★★★★★ | 1% | 50 |

### Stats
Each buddy has 5 stats: **DEBUGGING**, **PATIENCE**, **CHAOS**, **WISDOM**, **SNARK**. One peak stat (highest), one dump stat (lowest), rest random. Higher rarity = higher stat floor.

### Shiny
1% chance on hatch. Purely cosmetic bragging rights.

## Any-Buddy (Companion Customizer)

The `any-buddy` tool lets you pick any Claude Code companion pet you want — species, rarity, eyes, hat, and name — by brute-force searching for a salt that produces your chosen pet and patching the Claude Code binary.

### Quick Start

```bash
npx any-buddy@latest
```

### Any-Buddy Commands

| Command | Description |
|---|---|
| `any-buddy` | Interactive pet picker — choose species, rarity, eyes, hat, name and apply |
| `any-buddy current` | Show your current pet |
| `any-buddy preview` | Browse and preview pets without applying |
| `any-buddy apply` | Re-apply saved pet after a Claude Code update |
| `any-buddy apply --silent` | Silent re-apply (used by the SessionStart hook) |
| `any-buddy restore` | Restore original pet and remove the hook |
| `any-buddy rehatch` | Delete companion so Claude Code re-hatches a fresh one on next `/buddy` |

### Any-Buddy CLI Flags

| Flag | Short | Description |
|---|---|---|
| `--species <name>` | `-s` | Pre-select species |
| `--rarity <level>` | `-r` | Pre-select rarity |
| `--eye <char>` | `-e` | Pre-select eye style |
| `--hat <name>` | `-t` | Pre-select hat |
| `--name <name>` | `-n` | Rename your companion |
| `--personality <desc>` | `-p` | Set companion personality (controls speech bubble tone) |
| `--yes` | `-y` | Skip all confirmation prompts |
| `--shiny` | | Require shiny variant (~100x longer search) |
| `--peak <stat>` | | Best stat: DEBUGGING, PATIENCE, CHAOS, WISDOM, or SNARK |
| `--dump <stat>` | | Worst stat (~20x longer search with both) |
| `--no-hook` | | Don't offer to install the auto-patch hook |
| `--silent` | | Suppress output (for `apply` in hooks) |

See the full [any-buddy README](any-buddy/README.md) for details on how the binary patch works.

## Data

All collection data is stored in `~/.claude/buddy-collection.json`. Delete this file to reset everything.

## License

MIT
