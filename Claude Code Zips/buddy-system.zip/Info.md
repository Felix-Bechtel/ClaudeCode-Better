# Buddy Collection System — Info

A companion collection game for Claude Code. Hatch eggs, collect all 18 species, customize eyes and hats, and build your buddy roster.

## Quick Start

Run commands in Claude Code by typing `! <command>` in the chat prompt. For example: `! buddy stats`

## Install

Requires **Node.js >= 18**.

```bash
# Create a wrapper script on your PATH:
cat > ~/.local/bin/buddy << 'EOF'
#!/bin/bash
exec node ~/Claude/buddy-system/buddy.js "$@"
EOF
chmod +x ~/.local/bin/buddy
```

## Commands

| Command | Description |
|---|---|
| `buddy stats` | Show your active buddy with ASCII art, stat bars, age, and egg status |
| `buddy index` | View your collection grid — shows discovered and undiscovered species |
| `buddy log` | Full view: collection details + catalogue + customization reference |
| `buddy catalogue` | Browse all 18 species, eyes, hats, and rarities |
| `buddy equip` | Show all your buddies and which one is equipped |
| `buddy equip <name>` | Equip (switch to) a buddy |
| `buddy equip eyes <style>` | Change eyes on your active buddy |
| `buddy equip hat <type>` | Change hat on your active buddy |
| `buddy equip name <new>` | Rename your active buddy |
| `buddy claim` | Pick up any eggs your buddy has dropped |
| `buddy hatch` | Hatch a claimed egg into a new buddy |
| `buddy switch <name>` | Switch active buddy |
| `buddy release <name>` | Release a buddy from your collection |
| `buddy help` | Show command reference |

## Egg System

Your active buddy drops eggs over time based on its rarity:

| Buddy Rarity | Drop Speed (base) | Egg Rarity Chances |
|---|---|---|
| Common | 30s – 1.2 min | Common 70%, Uncommon 25%, Rare 5% |
| Uncommon | 40s – 1m 50s | Common 40%, Uncommon 35%, Rare 20%, Epic 5% |
| Rare | 1 – 3 min | Common 15%, Uncommon 30%, Rare 35%, Epic 15%, Legendary 5% |
| Epic | 2 – 5 min | Common 5%, Uncommon 15%, Rare 30%, Epic 35%, Legendary 15% |
| Legendary | 5 – 10 min | Uncommon 5%, Rare 20%, Epic 40%, Legendary 35% |

**Common buddies can NEVER drop legendary eggs.** Rarer buddies drop rarer eggs.

## Age System

Buddies age with active coding time:
- **1 year = 10 minutes** of active coding (Claude Code, iTerm, Cursor, or VS Code in focus)
- **Max age: 10 years** (100 minutes)
- **Each year reduces egg drop time by 10%** — at max age, eggs drop twice as fast

## Species (18 total, 5 rarities)

- **Common** (★): duck, goose, blob, snail, turtle, rabbit
- **Uncommon** (★★): cat, penguin, capybara, cactus, mushroom
- **Rare** (★★★): owl, ghost, chonk, robot
- **Epic** (★★★★): octopus, axolotl
- **Legendary** (★★★★★): dragon

## Customization

- **Eyes**: dot (·), sparkle (✦), cross (×), circle (◉), at (@), degree (°)
- **Hats**: crown, tophat, propeller, halo, wizard, beanie, tinyduck
- **Shiny**: 1% chance on hatch — cosmetic bragging rights

## Data

All collection data stored in `~/.claude/buddy-collection.json`. Delete to reset.
