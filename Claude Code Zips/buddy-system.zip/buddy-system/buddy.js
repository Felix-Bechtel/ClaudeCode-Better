#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// ─── Config ──────────────────────────────────────────────────────────

const DATA_FILE = path.join(process.env.HOME, '.claude', 'buddy-collection.json');

// ─── Colors ──────────────────────────────────────────────────────────

const R = '\x1b[0m';
const B = '\x1b[1m';
const D = '\x1b[2m';
const CYAN = '\x1b[36m';
const YEL = '\x1b[33m';
const GRN = '\x1b[32m';
const RED = '\x1b[31m';
const MAG = '\x1b[35m';
const WHT = '\x1b[37m';
const BLU = '\x1b[34m';

// ─── Species Art ─────────────────────────────────────────────────────

// % = eye placeholder (replaced at render time)
const SPECIES_ART = {
  duck: [
    '      __      ',
    '    <(% )___  ',
    '     (  ._>   ',
    '      `--\'    ',
  ],
  goose: [
    '      (%>     ',
    '       ||     ',
    '     _(__)_   ',
    '      ^^^^    ',
  ],
  blob: [
    '     .----.   ',
    '    ( %  % )  ',
    '    (      )  ',
    '     `----\'   ',
  ],
  cat: [
    '     /\\_/\\    ',
    '   ( %   %)   ',
    '   (  w  )    ',
    '   (")_(")    ',
  ],
  dragon: [
    '   /^\\  /^\\   ',
    '  <  %  %  >  ',
    '  (   ~~   )  ',
    '   `-vvvv-\'   ',
  ],
  octopus: [
    '     .----.   ',
    '    ( %  % )  ',
    '    (______)  ',
    '    /\\/\\/\\/\\  ',
  ],
  owl: [
    '    /\\  /\\    ',
    '  ((%)(%)  )  ',
    '  (  ><  )    ',
    '   `----\'     ',
  ],
  penguin: [
    '     .---.    ',
    '    (%>%)     ',
    '   /(   )\\   ',
    '    `---\'     ',
  ],
  turtle: [
    '    _,--._    ',
    '   ( %  % )   ',
    '  /[______]\\  ',
    '   ``    ``   ',
  ],
  snail: [
    '        .--.  ',
    '    \\  ( % )  ',
    '     \\_`--\'   ',
    '   ~~~~~~~    ',
  ],
  ghost: [
    '     .----.   ',
    '   / %  % \\   ',
    '   |      |   ',
    '   ~`~``~`~   ',
  ],
  axolotl: [
    ' }~(______)~{ ',
    ' }~(% .. %)~{ ',
    '   ( .--. )   ',
    '   (_/  \\_)   ',
  ],
  capybara: [
    '   n______n   ',
    '  ( %    % )  ',
    '  (   oo   )  ',
    '   `------\'   ',
  ],
  cactus: [
    '  n  ____  n  ',
    '  | |%  %| |  ',
    '  |_|    |_|  ',
    '    |    |    ',
  ],
  robot: [
    '    .[||].    ',
    '  [ %  % ]    ',
    '  [ ==== ]    ',
    '   `------\'   ',
  ],
  rabbit: [
    '    (\\__/)    ',
    '   ( %  % )   ',
    '  =(  ..  )=  ',
    '   (")__(")   ',
  ],
  mushroom: [
    '  .-o-OO-o-.  ',
    '  (__________) ',
    '    |%  %|    ',
    '    |____|    ',
  ],
  chonk: [
    '   /\\    /\\   ',
    '  ( %    % )  ',
    '  (   ..   )  ',
    '   `------\'   ',
  ],
};

const HAT_ART = {
  crown:     '\\^^^/',
  tophat:    '[___]',
  propeller: ' -+- ',
  halo:      '(   )',
  wizard:    ' /^\\ ',
  beanie:    '(___)',
  tinyduck:  '  ,> ',
};

const RARITIES = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
const RARITY_STARS = { common: '\u2605', uncommon: '\u2605\u2605', rare: '\u2605\u2605\u2605', epic: '\u2605\u2605\u2605\u2605', legendary: '\u2605\u2605\u2605\u2605\u2605' };
const RARITY_COLOR = { common: WHT, uncommon: GRN, rare: CYAN, epic: MAG, legendary: YEL };
const RARITY_FLOOR = { common: 5, uncommon: 15, rare: 25, epic: 35, legendary: 50 };
const EYES = ['\u00b7', '\u2726', '\u00d7', '\u25c9', '@', '\u00b0'];
const EYE_NAMES = { '\u00b7': 'dot', '\u2726': 'sparkle', '\u00d7': 'cross', '\u25c9': 'circle', '@': 'at', '\u00b0': 'degree' };
const HAT_NAMES = ['none', 'crown', 'tophat', 'propeller', 'halo', 'wizard', 'beanie', 'tinyduck'];
const STAT_NAMES = ['DEBUGGING', 'PATIENCE', 'CHAOS', 'WISDOM', 'SNARK'];
const ALL_SPECIES = Object.keys(SPECIES_ART);

// ─── Data ────────────────────────────────────────────────────────────

function loadData() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    const data = {
      active: 'quipster',
      buddies: [{
        id: 'quipster',
        name: 'Quipster',
        species: 'duck',
        rarity: 'common',
        eyes: '@',
        hat: 'none',
        shiny: false,
        stats: { DEBUGGING: 45, PATIENCE: 8, CHAOS: 30, WISDOM: 25, SNARK: 72 },
        acquired: new Date().toISOString().split('T')[0],
        source: 'original',
      }],
      eggs: [],
      totalHatched: 0,
      lastEggCheck: Date.now(),
    };
    saveData(data);
    return data;
  }
}

function saveData(data) {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// ─── Helpers ─────────────────────────────────────────────────────────

function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function rollRarity() {
  const r = Math.random() * 100;
  if (r < 1) return 'legendary';
  if (r < 5) return 'epic';
  if (r < 15) return 'rare';
  if (r < 40) return 'uncommon';
  return 'common';
}

function rollStats(rarity) {
  const floor = RARITY_FLOOR[rarity];
  const stats = {};
  const peak = pick(STAT_NAMES);
  const dump = pick(STAT_NAMES.filter(s => s !== peak));
  for (const s of STAT_NAMES) {
    if (s === peak) stats[s] = rand(Math.max(floor, 60), 99);
    else if (s === dump) stats[s] = rand(1, Math.min(floor + 5, 20));
    else stats[s] = rand(floor, 70);
  }
  return stats;
}

function renderArt(species, eyes, hat) {
  const eyeChar = eyes || '\u00b7';
  const art = SPECIES_ART[species].map(line => line.replace(/%/g, eyeChar));
  if (hat && hat !== 'none' && HAT_ART[hat]) {
    const maxW = Math.max(...art.map(l => l.length));
    const h = HAT_ART[hat];
    const pad = ' '.repeat(Math.max(0, Math.floor((maxW - h.length) / 2)));
    return [pad + h, ...art];
  }
  return art;
}

function statBar(val, width = 20) {
  const filled = Math.round((val / 99) * width);
  return '\u2588'.repeat(filled) + '\u2591'.repeat(width - filled);
}

function generateName() {
  const pre = ['Pip', 'Zap', 'Boo', 'Nix', 'Dot', 'Fizz', 'Glo', 'Rex', 'Jinx', 'Wiz',
    'Blip', 'Chip', 'Dex', 'Echo', 'Flux', 'Hex', 'Ink', 'Jazz', 'Kip', 'Lux',
    'Mox', 'Neo', 'Orb', 'Pix', 'Quirk', 'Rune', 'Spark', 'Tux', 'Vex', 'Wren',
    'Ash', 'Bolt', 'Cog', 'Drift', 'Ember', 'Fern', 'Grit', 'Haze', 'Ion', 'Jade'];
  const suf = ['ster', 'o', 'by', 'kin', 'let', 'bit', 'pop', 'zee', 'wick', 'belle',
    'bolt', 'dash', 'flare', 'gust', 'mint', 'ix', 'jet', 'knack', 'loom', 'spark'];
  return pick(pre) + pick(suf);
}

function stripAnsi(s) {
  return s.replace(/\x1b\[[0-9;]*m/g, '');
}

// ─── Egg System ──────────────────────────────────────────────────────

function checkForEggs(data) {
  const now = Date.now();
  const elapsed = now - (data.lastEggCheck || now);
  const mins = elapsed / (1000 * 60);

  if (mins < 10) return null; // min 10 min between drops

  data.lastEggCheck = now;
  const active = data.buddies.find(b => b.id === data.active);
  if (!active) { saveData(data); return null; }

  // Ducks: 50% chance, others: 20%
  const chance = active.species === 'duck' ? 0.50 : 0.20;
  const timeBonus = Math.min(mins / 120, 1.5); // up to 1.5x at 2hrs

  if (Math.random() < chance * timeBonus) {
    const egg = {
      id: 'egg-' + Date.now(),
      droppedBy: active.id,
      droppedByName: active.name,
      droppedBySpecies: active.species,
      droppedAt: new Date().toISOString(),
      claimed: false,
    };
    data.eggs.push(egg);
    saveData(data);
    return egg;
  }
  saveData(data);
  return null;
}

// ─── Display Helpers ─────────────────────────────────────────────────

const W = 50;
const HR = '\u2500'.repeat(W);

function header(title) {
  console.log(`${D}\u250c${HR}\u2500${R}`);
  console.log(`${D}\u2502${R} ${B}${title}${R}`);
  console.log(`${D}\u251c${HR}\u2500${R}`);
}

function divider() {
  console.log(`${D}\u251c${HR}\u2500${R}`);
}

function footer() {
  console.log(`${D}\u2514${HR}\u2500${R}`);
}

function row(text) {
  console.log(`${D}\u2502${R} ${text}`);
}

function blank() {
  console.log(`${D}\u2502${R}`);
}

// ─── Commands ────────────────────────────────────────────────────────

function cmdStats(data) {
  const buddy = data.buddies.find(b => b.id === data.active);
  if (!buddy) { console.log(`${RED}  No active buddy!${R}`); return; }

  const newEgg = checkForEggs(data);
  const rc = RARITY_COLOR[buddy.rarity];
  const stars = RARITY_STARS[buddy.rarity];
  const shinyTag = buddy.shiny ? ` ${YEL}\u2727 SHINY \u2727${R}` : '';
  const eyeName = EYE_NAMES[buddy.eyes] || buddy.eyes;

  console.log();
  header(`${buddy.name}  ${rc}${stars}${R}${shinyTag}`);
  row(`${D}${buddy.species} \u00b7 eyes: ${buddy.eyes} (${eyeName}) \u00b7 hat: ${buddy.hat}${R}`);
  divider();

  const art = renderArt(buddy.species, buddy.eyes, buddy.hat);
  blank();
  for (const line of art) {
    row(`    ${CYAN}${line}${R}`);
  }
  blank();

  divider();
  for (const stat of STAT_NAMES) {
    const val = buddy.stats[stat] || 0;
    let col = WHT;
    if (val >= 70) col = GRN;
    else if (val >= 40) col = CYAN;
    else if (val <= 15) col = RED;
    row(`  ${stat.padEnd(10)} ${col}${statBar(val)}${R} ${B}${String(val).padStart(2)}${R}`);
  }

  divider();
  const unclaimed = data.eggs.filter(e => !e.claimed).length;
  const claimed = data.eggs.filter(e => e.claimed).length;
  const total = data.buddies.length;
  const species = new Set(data.buddies.map(b => b.species)).size;
  row(`  Collection: ${B}${total}${R} buddies \u00b7 ${B}${species}${R}/18 species`);
  row(`  Eggs: ${YEL}${unclaimed} unclaimed${R} \u00b7 ${GRN}${claimed} ready to hatch${R}`);
  footer();

  if (newEgg) {
    console.log();
    console.log(`  ${YEL}\ud83e\udd5a ${buddy.name} dropped an egg!${R}`);
    console.log(`  ${D}Run ${WHT}buddy claim${D} to pick it up${R}`);
  }
  console.log();
}

function cmdIndex(data) {
  console.log();
  const species = new Set(data.buddies.map(b => b.species)).size;
  header(`BUDDY INDEX  ${D}\u2014  ${data.buddies.length} collected \u00b7 ${species}/18 species${R}`);

  for (const sp of ALL_SPECIES) {
    const owned = data.buddies.filter(b => b.species === sp);
    if (owned.length > 0) {
      const firstOwned = owned[0];
      const artLine = (SPECIES_ART[sp][1] || SPECIES_ART[sp][0]).replace(/%/g, firstOwned.eyes).trim();
      const names = owned.map(b => {
        const rc = RARITY_COLOR[b.rarity];
        const active = b.id === data.active ? ` ${GRN}\u25c4${R}` : '';
        return `${rc}${b.name}${R}${active}`;
      }).join(', ');
      row(`  ${CYAN}${sp.padEnd(10)}${R} ${D}${artLine.padEnd(16)}${R} ${names}`);
    } else {
      row(`  ${D}${sp.padEnd(10)} ${'???'.padEnd(16)} (undiscovered)${R}`);
    }
  }

  divider();
  const unclaimed = data.eggs.filter(e => !e.claimed).length;
  const claimed = data.eggs.filter(e => e.claimed).length;
  row(`  ${YEL}Eggs:${R} ${unclaimed} unclaimed \u00b7 ${claimed} ready to hatch \u00b7 ${data.totalHatched || 0} total hatched`);
  footer();
  console.log();
}

function cmdCatalogue() {
  const speciesCount = ALL_SPECIES.length;
  const RARITY_ODDS = { common: 60, uncommon: 25, rare: 10, epic: 4, legendary: 1 };
  console.log();
  header('SPECIES CATALOGUE');
  for (const sp of ALL_SPECIES) {
    const art = SPECIES_ART[sp];
    row(`  ${B}${CYAN}${sp}${R}  ${D}(1/${speciesCount})${R}`);
    for (const line of art) {
      row(`    ${D}${line}${R}`);
    }
    blank();
  }
  divider();
  row(`  ${B}EYES${R}  ${EYES.map(e => `${e} (${EYE_NAMES[e]})`).join('  ')}`);
  blank();
  row(`  ${B}HATS${R}  ${HAT_NAMES.filter(h => h !== 'none').map(h => `${HAT_ART[h]} ${h}`).join('  ')}`);
  blank();
  row(`  ${B}RARITIES${R}`);
  for (const r of RARITIES) {
    const pct = RARITY_ODDS[r];
    const denom = Math.round(100 / pct);
    row(`    ${RARITY_COLOR[r]}${RARITY_STARS[r]} ${r}${R}  ${D}(1/${denom} eggs · ${pct}%)${R}`);
  }
  footer();
  console.log();
}

function cmdEquip(data, args) {
  const what = args[0];
  const val = args.slice(1).join(' ');

  // No args or a buddy name → show list / equip (switch) a buddy
  if (!what || !['eyes', 'hat', 'name'].includes(what)) {
    // Check if they're trying to equip a buddy by name
    const nameArg = args.join(' ');
    if (nameArg) {
      const target = data.buddies.find(b => b.name.toLowerCase() === nameArg.toLowerCase());
      if (target) {
        data.active = target.id;
        data.lastEggCheck = Date.now();
        saveData(data);
        const rc = RARITY_COLOR[target.rarity];
        const stars = RARITY_STARS[target.rarity];
        console.log();
        console.log(`  ${GRN}\u2713${R} Equipped ${B}${target.name}${R}! ${rc}${stars}${R}`);
        const art = renderArt(target.species, target.eyes, target.hat);
        for (const line of art) console.log(`     ${CYAN}${line}${R}`);
        console.log();
        return;
      }
    }

    // Show buddy list to equip
    console.log();
    header('EQUIP A BUDDY');
    blank();
    for (const b of data.buddies) {
      const rc = RARITY_COLOR[b.rarity];
      const stars = RARITY_STARS[b.rarity];
      const active = b.id === data.active ? ` ${GRN}\u25c4 equipped${R}` : '';
      const artLine = (SPECIES_ART[b.species][1] || '').replace(/%/g, b.eyes).trim();
      row(`  ${rc}${B}${b.name}${R}${active}  ${D}${b.species} ${stars} \u00b7 ${b.eyes} \u00b7 ${b.hat}${R}`);
      row(`    ${CYAN}${artLine}${R}`);
      blank();
    }
    divider();
    row(`  ${D}${WHT}buddy equip <name>${D}         Equip a buddy${R}`);
    row(`  ${D}${WHT}buddy equip eyes <style>${D}   Change eyes${R}`);
    row(`  ${D}${WHT}buddy equip hat <type>${D}     Change hat${R}`);
    row(`  ${D}${WHT}buddy equip name <name>${D}    Rename active buddy${R}`);
    footer();
    console.log();
    return;
  }

  const buddy = data.buddies.find(b => b.id === data.active);
  if (!buddy) { console.log(`${RED}  No active buddy!${R}`); return; }

  if (what === 'eyes') {
    // Accept eye character directly or name
    let eye = val;
    const byName = Object.entries(EYE_NAMES).find(([ch, name]) => name === val.toLowerCase());
    if (byName) eye = byName[0];
    if (!EYES.includes(eye)) {
      console.log(`  ${RED}Unknown eye style "${val}".${R}`);
      console.log(`  ${D}Options: ${EYES.map(e => `${e} (${EYE_NAMES[e]})`).join(', ')}${R}`);
      return;
    }
    buddy.eyes = eye;
    saveData(data);
    console.log(`  ${GRN}\u2713${R} ${B}${buddy.name}${R} now has ${B}${eye}${R} (${EYE_NAMES[eye]}) eyes!`);
    const art = renderArt(buddy.species, buddy.eyes, buddy.hat);
    for (const line of art) console.log(`     ${CYAN}${line}${R}`);
  }

  if (what === 'hat') {
    const hat = val.toLowerCase();
    if (!HAT_NAMES.includes(hat)) {
      console.log(`  ${RED}Unknown hat "${val}".${R}`);
      console.log(`  ${D}Options: ${HAT_NAMES.join(', ')}${R}`);
      return;
    }
    if (hat !== 'none' && buddy.rarity === 'common') {
      console.log(`  ${YEL}Note: Common buddies don't usually wear hats, but sure!${R}`);
    }
    buddy.hat = hat;
    saveData(data);
    console.log(`  ${GRN}\u2713${R} ${B}${buddy.name}${R} now wears: ${B}${hat}${R}!`);
    const art = renderArt(buddy.species, buddy.eyes, buddy.hat);
    for (const line of art) console.log(`     ${CYAN}${line}${R}`);
  }

  if (what === 'name') {
    if (!val) { console.log(`  ${RED}Provide a name!${R}`); return; }
    const old = buddy.name;
    buddy.name = val;
    saveData(data);
    console.log(`  ${GRN}\u2713${R} Renamed ${D}${old}${R} \u2192 ${B}${val}${R}`);
  }
}

function cmdClaim(data) {
  const unclaimed = data.eggs.filter(e => !e.claimed);
  if (unclaimed.length === 0) {
    console.log();
    console.log(`  ${D}No unclaimed eggs right now.${R}`);
    console.log(`  ${D}Run ${WHT}buddy stats${D} to check \u2014 your buddy drops eggs over time!${R}`);
    console.log();
    return;
  }

  console.log();
  for (const egg of unclaimed) {
    egg.claimed = true;
    console.log(`  ${GRN}\u2713${R} Claimed egg from ${B}${egg.droppedByName}${R} (${egg.droppedBySpecies})`);
  }
  saveData(data);
  const ready = data.eggs.filter(e => e.claimed).length;
  console.log();
  console.log(`  ${D}You have ${WHT}${ready}${D} egg(s) ready to hatch.${R}`);
  console.log(`  ${D}Run ${WHT}buddy hatch${D} to hatch one!${R}`);
  console.log();
}

function cmdHatch(data) {
  const ready = data.eggs.filter(e => e.claimed);
  if (ready.length === 0) {
    const unclaimed = data.eggs.filter(e => !e.claimed).length;
    if (unclaimed > 0) {
      console.log(`  ${YEL}You have ${unclaimed} unclaimed egg(s). Run ${WHT}buddy claim${YEL} first!${R}`);
    } else {
      console.log(`  ${D}No eggs to hatch. Your buddy drops them over time.${R}`);
    }
    return;
  }

  const egg = ready[0];
  data.eggs = data.eggs.filter(e => e.id !== egg.id);

  const species = pick(ALL_SPECIES);
  const rarity = rollRarity();
  const eyes = pick(EYES);
  const hat = rarity === 'common' ? 'none' : pick(HAT_NAMES.filter(h => h !== 'none'));
  const shiny = Math.random() < 0.01;
  const stats = rollStats(rarity);
  const name = generateName();
  const id = name.toLowerCase().replace(/\s/g, '-') + '-' + Date.now();

  const rc = RARITY_COLOR[rarity];
  const stars = RARITY_STARS[rarity];
  const shinyTag = shiny ? ` ${YEL}\u2727 SHINY \u2727${R}` : '';
  const art = renderArt(species, eyes, hat);

  data.totalHatched = (data.totalHatched || 0) + 1;

  // Check for duplicate species
  const isDupe = data.buddies.some(b => b.species === species);

  console.log();
  console.log(`  ${YEL}\ud83e\udd5a Cracking egg from ${egg.droppedByName}...${R}`);
  console.log();
  for (const line of art) console.log(`     ${CYAN}${line}${R}`);
  console.log();

  if (isDupe) {
    // Duplicate — don't add to collection
    data.dupes = (data.dupes || 0) + 1;
    saveData(data);

    console.log(`  ${D}A ${species} appeared...${R}  ${rc}${stars}${R}${shinyTag}`);
    console.log(`  ${RED}But you already have a ${species}! It wandered off.${R}`);
    console.log();
    console.log(`  ${D}Duplicates: ${data.dupes} total \u00b7 ${new Set(data.buddies.map(b => b.species)).size}/18 species discovered${R}`);
    console.log(`  ${D}Remaining eggs: ${data.eggs.filter(e => e.claimed).length} ready, ${data.eggs.filter(e => !e.claimed).length} unclaimed${R}`);
    console.log();
    return;
  }

  // New species — add to collection!
  const newBuddy = {
    id, name, species, rarity, eyes, hat, shiny, stats,
    acquired: new Date().toISOString().split('T')[0],
    source: `hatched from ${egg.droppedByName}'s egg`,
  };

  data.buddies.push(newBuddy);
  saveData(data);

  console.log(`  ${GRN}\u2605 NEW SPECIES! \u2605${R}`);
  console.log(`  ${B}${name}${R} hatched!  ${rc}${species} ${stars}${R}${shinyTag}`);
  console.log(`  ${D}eyes: ${eyes} (${EYE_NAMES[eyes]}) \u00b7 hat: ${hat}${R}`);
  console.log();

  for (const stat of STAT_NAMES) {
    const val = stats[stat] || 0;
    let col = WHT;
    if (val >= 70) col = GRN;
    else if (val >= 40) col = CYAN;
    else if (val <= 15) col = RED;
    console.log(`  ${stat.padEnd(10)} ${col}${statBar(val, 15)}${R} ${B}${val}${R}`);
  }

  console.log();
  console.log(`  ${D}${new Set(data.buddies.map(b => b.species)).size}/18 species discovered!${R}`);
  console.log(`  ${D}Run ${WHT}buddy equip ${name.toLowerCase()}${D} to equip them${R}`);
  console.log(`  ${D}Remaining eggs: ${data.eggs.filter(e => e.claimed).length} ready, ${data.eggs.filter(e => !e.claimed).length} unclaimed${R}`);
  console.log();
}

function cmdRelease(data, nameArg) {
  if (!nameArg) {
    console.log(`  ${RED}Usage: buddy release <name>${R}`);
    console.log(`  ${D}Your buddies:${R}`);
    for (const b of data.buddies) {
      const active = b.id === data.active ? ` ${GRN}\u25c4 active${R}` : '';
      const rc = RARITY_COLOR[b.rarity];
      console.log(`    ${rc}${b.name}${R} (${b.species})${active}`);
    }
    return;
  }

  const target = data.buddies.find(b =>
    b.name.toLowerCase() === nameArg.toLowerCase() ||
    b.id === nameArg.toLowerCase()
  );

  if (!target) {
    console.log(`  ${RED}No buddy named "${nameArg}".${R}`);
    return;
  }

  if (data.buddies.length === 1) {
    console.log(`  ${RED}Can't release your only buddy!${R}`);
    return;
  }

  if (target.id === data.active) {
    const other = data.buddies.find(b => b.id !== target.id);
    data.active = other.id;
    console.log(`  ${D}Switched active to ${WHT}${other.name}${R}`);
  }

  data.buddies = data.buddies.filter(b => b.id !== target.id);
  saveData(data);

  const rc = RARITY_COLOR[target.rarity];
  console.log(`  ${D}Released ${rc}${target.name}${R} ${D}(${target.species}). Bye bye!${R}`);
}

function cmdSwitch(data, nameArg) {
  if (!nameArg) {
    console.log();
    console.log(`  ${B}Your buddies:${R}`);
    for (const b of data.buddies) {
      const active = b.id === data.active ? ` ${GRN}\u25c4 active${R}` : '';
      const rc = RARITY_COLOR[b.rarity];
      const stars = RARITY_STARS[b.rarity];
      console.log(`    ${rc}${b.name}${R} (${b.species}) ${D}${stars}${R}${active}`);
    }
    console.log();
    console.log(`  ${D}Usage: ${WHT}buddy switch <name>${R}`);
    console.log();
    return;
  }

  const target = data.buddies.find(b => b.name.toLowerCase() === nameArg.toLowerCase());
  if (!target) {
    console.log(`  ${RED}No buddy named "${nameArg}".${R}`);
    return;
  }

  data.active = target.id;
  data.lastEggCheck = Date.now(); // reset egg timer on switch
  saveData(data);
  console.log(`  ${GRN}\u2713${R} ${B}${target.name}${R} is now your active buddy!`);
}

function cmdLog(data) {
  // Combined view: index + catalogue + equip info
  console.log();
  const species = new Set(data.buddies.map(b => b.species)).size;
  header(`BUDDY LOG  ${D}\u2014  ${data.buddies.length} collected \u00b7 ${species}/18 species${R}`);

  // Your collection
  row(`  ${B}YOUR COLLECTION${R}`);
  blank();
  for (const b of data.buddies) {
    const rc = RARITY_COLOR[b.rarity];
    const stars = RARITY_STARS[b.rarity];
    const active = b.id === data.active ? ` ${GRN}\u25c4 active${R}` : '';
    const shinyTag = b.shiny ? ` ${YEL}\u2727${R}` : '';
    const artLine = (SPECIES_ART[b.species][1] || '').trim();
    const eyeName = EYE_NAMES[b.eyes] || b.eyes;
    row(`  ${rc}${B}${b.name}${R}${active}${shinyTag}`);
    row(`    ${CYAN}${artLine.replace(/%/g, b.eyes)}${R}  ${D}${b.species} ${stars} \u00b7 eyes: ${b.eyes} (${eyeName}) \u00b7 hat: ${b.hat}${R}`);
    const topStat = STAT_NAMES.reduce((a, s) => (b.stats[s] > (b.stats[a] || 0) ? s : a), STAT_NAMES[0]);
    row(`    ${D}Best: ${topStat} ${b.stats[topStat]} \u00b7 acquired: ${b.acquired} \u00b7 ${b.source}${R}`);
    blank();
  }

  divider();

  // Undiscovered species
  const ownedSpecies = new Set(data.buddies.map(b => b.species));
  const missing = ALL_SPECIES.filter(s => !ownedSpecies.has(s));
  if (missing.length > 0) {
    row(`  ${B}UNDISCOVERED${R} ${D}(${missing.length} species)${R}`);
    row(`  ${D}${missing.join(', ')}${R}`);
    blank();
  }

  divider();

  // Customization reference
  row(`  ${B}CUSTOMIZATION${R}  ${D}\u2014 use ${WHT}buddy equip${D} to change${R}`);
  blank();
  row(`  ${B}Eyes:${R} ${EYES.map(e => `${e} ${D}${EYE_NAMES[e]}${R}`).join('  ')}`);
  row(`  ${B}Hats:${R} ${HAT_NAMES.filter(h => h !== 'none').map(h => `${HAT_ART[h]} ${D}${h}${R}`).join('  ')}  ${D}none${R}`);
  row(`  ${B}Rarity:${R} ${RARITIES.map(r => `${RARITY_COLOR[r]}${RARITY_STARS[r]} ${r}${R}`).join('  ')}`);
  blank();
  row(`  ${D}${WHT}buddy equip eyes sparkle${D}  \u2014 change eyes${R}`);
  row(`  ${D}${WHT}buddy equip hat wizard${D}    \u2014 change hat${R}`);
  row(`  ${D}${WHT}buddy equip name Sparky${D}   \u2014 rename buddy${R}`);

  divider();

  // Egg status
  const unclaimed = data.eggs.filter(e => !e.claimed).length;
  const claimed = data.eggs.filter(e => e.claimed).length;
  row(`  ${B}EGGS${R}  ${YEL}${unclaimed} unclaimed${R} \u00b7 ${GRN}${claimed} ready${R} \u00b7 ${D}${data.totalHatched || 0} hatched total${R}`);
  footer();
  console.log();
}

function cmdHelp() {
  console.log();
  console.log(`  ${B}buddy${R} \u2014 Companion Collection Manager`);
  console.log();
  console.log(`  ${WHT}buddy stats${R}              Active buddy stats panel`);
  console.log(`  ${WHT}buddy index${R}              Species collection grid`);
  console.log(`  ${WHT}buddy log${R}                Full log: collection + catalogue + equip`);
  console.log(`  ${WHT}buddy catalogue${R}          Browse all 18 species & customizations`);
  console.log(`  ${WHT}buddy equip <what> <val>${R} Change eyes/hat/name on active buddy`);
  console.log(`  ${WHT}buddy claim${R}              Pick up dropped eggs`);
  console.log(`  ${WHT}buddy hatch${R}              Hatch a claimed egg into a new buddy`);
  console.log(`  ${WHT}buddy switch <name>${R}      Switch active buddy`);
  console.log(`  ${WHT}buddy release <name>${R}     Release a buddy from collection`);
  console.log(`  ${WHT}buddy help${R}               Show this help`);
  console.log();
  console.log(`  ${D}Ducks drop eggs more often! Check ${WHT}buddy stats${D} regularly.${R}`);
  console.log();
}

// ─── Main ────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
const cmd = args[0] || 'help';

const data = loadData();

switch (cmd) {
  case 'stats':     cmdStats(data); break;
  case 'index':     cmdIndex(data); break;
  case 'log':       cmdLog(data); break;
  case 'catalogue':
  case 'catalog':   cmdCatalogue(); break;
  case 'equip':     cmdEquip(data, args.slice(1)); break;
  case 'claim':     cmdClaim(data); break;
  case 'hatch':     cmdHatch(data); break;
  case 'release':   cmdRelease(data, args.slice(1).join(' ')); break;
  case 'switch':    cmdSwitch(data, args.slice(1).join(' ')); break;
  case 'help':      cmdHelp(); break;
  default:
    console.log(`  ${RED}Unknown command: ${cmd}${R}`);
    cmdHelp();
}
