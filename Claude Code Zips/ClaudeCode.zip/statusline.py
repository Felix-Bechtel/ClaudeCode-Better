#!/usr/bin/env python3
"""token-tracker v8 — account-synced usage with keychain tier detection.
Shows account-level token usage, session cost, context window, effort level.
"""

import json
import os
import sys
import subprocess
import time
from pathlib import Path

# ── Colors ──
R = '\x1b[0m'; B = '\x1b[1m'; D = '\x1b[2m'
W = '\x1b[97m'; CN = '\x1b[36m'; G = '\x1b[32m'
Y = '\x1b[33m'; RD = '\x1b[91m'; MG = '\x1b[35m'
BL = '\x1b[34m'; GY = '\x1b[90m'
SEP = f'{GY}\u2502{R}'

# ── Cache (3s TTL for live-feeling refresh; matches statusLine.refreshInterval) ──
CACHE_FILE = Path(os.environ.get('TMPDIR', '/tmp')) / 'token-tracker-usage.json'
EFFORT_FILE = Path(os.environ.get('TMPDIR', '/tmp')) / 'claude-effort'
CACHE_TTL = 3


def get_keychain_credentials():
    """Read Claude Code OAuth credentials from macOS Keychain (cached per process).
    The keychain can hold multiple entries under service 'Claude Code-credentials'
    (one per account). Default lookup returns the first one, which is often empty
    ('unknown' account). Enumerate accounts and pick the first with a real token.
    """
    if not hasattr(get_keychain_credentials, '_cache'):
        get_keychain_credentials._cache = {}
        if sys.platform == 'darwin':
            # Accounts to try, in order of preference. Shell login name is the
            # most common real entry on macOS.
            candidates = [os.environ.get('USER') or '', 'claude', 'claudeai', 'anthropic']
            # Also try the default (no -a flag) as fallback
            candidates.append(None)
            for acct in candidates:
                try:
                    cmd = ['security', 'find-generic-password', '-s', 'Claude Code-credentials', '-w']
                    if acct:
                        cmd += ['-a', acct]
                    raw = subprocess.run(cmd, capture_output=True, text=True, timeout=2).stdout.strip()
                    if not raw:
                        continue
                    parsed = json.loads(raw)
                    co = parsed.get('claudeAiOauth') or {}
                    if co.get('accessToken'):
                        get_keychain_credentials._cache = co
                        break
                except Exception:
                    continue
    return get_keychain_credentials._cache


def get_oauth_token():
    # 1) Env var
    env_tok = os.environ.get('CLAUDE_CODE_OAUTH_TOKEN')
    if env_tok:
        try:
            env = json.loads(env_tok)
            return env.get('accessToken') or (env.get('claudeAiOauth') or {}).get('accessToken')
        except (json.JSONDecodeError, TypeError):
            if env_tok.startswith('sk-ant-'):
                return env_tok
    # 2) Keychain (reuse cached credentials)
    creds = get_keychain_credentials()
    if creds.get('accessToken'):
        return creds['accessToken']
    # 3) Credentials file
    config_dir = Path(os.environ.get('CLAUDE_CONFIG_DIR', Path.home() / '.claude'))
    try:
        c = json.loads((config_dir / '.credentials.json').read_text())
        return (c.get('claudeAiOauth') or {}).get('accessToken') or c.get('accessToken')
    except Exception:
        pass
    return None


def get_live_usage():
    # Fast path: cache hit (valid data only)
    try:
        cached = json.loads(CACHE_FILE.read_text())
        if cached.get('_ts') and not cached.get('error') and time.time() - cached['_ts'] < CACHE_TTL:
            return cached
    except Exception:
        pass

    # Slow path: curl API (max 2s)
    token = get_oauth_token()
    if not token:
        return None
    try:
        result = subprocess.run(
            ['curl', '-s', '--max-time', '2',
             '-H', 'Accept: application/json',
             '-H', f'Authorization: Bearer {token}',
             '-H', 'anthropic-beta: oauth-2025-04-20',
             'https://api.anthropic.com/api/oauth/usage'],
            capture_output=True, text=True, timeout=3
        )
        out = result.stdout.strip()
        if out:
            data = json.loads(out)
            if data.get('error'):
                pass  # don't cache error responses
            else:
                data['_ts'] = time.time()
                try:
                    CACHE_FILE.write_text(json.dumps(data))
                except Exception:
                    pass
                return data
    except Exception:
        pass

    # Stale cache fallback — only if less than 60s old (prefer stdin over ancient cache)
    try:
        cached = json.loads(CACHE_FILE.read_text())
        if not cached.get('error') and cached.get('_ts') and (time.time() - cached['_ts']) < 60:
            return cached
    except Exception:
        pass
    return None


def fmt(n):
    if n >= 1e6:
        return f'{n/1e6:.1f}M'
    if n >= 1e3:
        return f'{n/1e3:.1f}k'
    return str(n)


def color_pct(p):
    if p < 30: return G
    if p < 50: return CN
    if p < 75: return Y
    return RD


def bar(p, w=10):
    f = min(round(p / 100 * w), w)
    return '\u2588' * f + '\u2591' * (w - f)


def fmt_reset(r):
    if not r:
        return ''
    if isinstance(r, str):
        from datetime import datetime
        try:
            ts = int(datetime.fromisoformat(r.replace('Z', '+00:00')).timestamp())
        except Exception:
            return ''
    else:
        ts = int(r)
    d = max(0, ts - int(time.time()))
    if d <= 0:
        return 'now'
    days = d // 86400
    h = (d % 86400) // 3600
    m = (d % 3600) // 60
    if days > 0:
        return f'{days}d {h}h'
    if h > 0:
        return f'{h}h {m}m'
    return f'{m}m'


def _norm_bucket(raw):
    """Normalize a rate-limit bucket dict into {pct, reset}. Returns None if missing."""
    if not raw:
        return None
    p = raw.get('used_percentage')
    if p is None:
        p = raw.get('utilization')
    if p is None:
        return None
    p = float(p)
    if 0 < p <= 1:
        p *= 100
    return {'pct': round(p), 'pct_raw': p, 'reset': raw.get('resets_at')}


# Aliases for each logical bucket — different sources use different keys.
BUCKET_ALIASES = {
    'five_hour':       ('five_hour', 'fiveHour', '5h', 'session', 'rolling_5h'),
    'seven_day':       ('seven_day', 'sevenDay', '7d', 'weekly', 'rolling_7d'),
    'seven_day_opus':  ('seven_day_opus', 'sevenDayOpus', '7d_opus', 'weekly_opus',
                        'opus_weekly', 'rolling_7d_opus'),
}


def get_rate_limit(d, live, logical_key):
    """Get rate limit data for a logical bucket from live API first (if fresh), then stdin."""
    aliases = BUCKET_ALIASES.get(logical_key, (logical_key,))

    # Prefer live API data only if fresh (< 30s old)
    if live and live.get('_ts') and (time.time() - live['_ts']) < 30:
        for k in aliases:
            b = _norm_bucket(live.get(k))
            if b:
                return b
        # Some APIs nest under "rate_limits"
        rl_live = live.get('rate_limits') or {}
        for k in aliases:
            b = _norm_bucket(rl_live.get(k))
            if b:
                return b

    # Fallback to stdin rate limits
    rl = d.get('rate_limits') or {}
    for k in aliases:
        b = _norm_bucket(rl.get(k))
        if b:
            return b
    return None


def get_settings():
    """Read settings.json once, cached for the process lifetime."""
    if not hasattr(get_settings, '_cache'):
        try:
            get_settings._cache = json.loads(Path(Path.home() / '.claude' / 'settings.json').read_text())
        except Exception:
            get_settings._cache = {}
    return get_settings._cache


def get_effort(d=None):
    """Read effort level: session temp file > stdin output_style > settings.json."""
    # 1) Session temp file (written by UserPromptSubmit hook on /effort)
    try:
        level = EFFORT_FILE.read_text().strip().lower()
        if level in ('low', 'medium', 'high', 'max'):
            return level
    except Exception:
        pass
    # 2) Check stdin session data — output_style.name
    if d:
        style = (d.get('output_style') or {}).get('name')
        if style and style != 'default':
            return style
    # 3) Fall back to settings.json
    return get_settings().get('effortLevel')


# ── Tier detection from keychain credentials ──
TIER_MAP = {
    'default_claude_pro': 44000,
    'pro': 44000,
    'default_claude_max_5x': 88000,
    'max_5x': 88000,
    '5x': 88000,
    'default_claude_max_20x': 220000,
    'max_20x': 220000,
    '20x': 220000,
}


def get_token_budget(live):
    """Detect token budget: explicit override > keychain tier > live API > default."""
    # 0) Explicit override in settings.json — wins over everything so the user
    # can lock the displayed budget to their actual plan (e.g. Max 5x = 88000)
    # when keychain/live detection is flaky.
    override = get_settings().get('statusLineTokenBudget')
    if override:
        return int(override)
    # 1) Keychain credentials — most reliable source
    creds = get_keychain_credentials()
    tier = (creds.get('rateLimitTier') or '').lower()
    if tier in TIER_MAP:
        return TIER_MAP[tier]
    # Infer from subscriptionType
    sub = (creds.get('subscriptionType') or '').lower()
    if sub == 'max':
        # Default max to 5x if specific tier not identified
        return 88000
    if sub == 'pro':
        return 44000

    # 2) Check live API data for tier/plan info
    if live:
        for key in ('plan', 'tier', 'subscription', 'plan_tier'):
            t = live.get(key)
            if t and str(t).lower() in TIER_MAP:
                return TIER_MAP[str(t).lower()]
        acct = live.get('account') or {}
        for key in ('plan', 'tier', 'subscription'):
            t = acct.get(key)
            if t and str(t).lower() in TIER_MAP:
                return TIER_MAP[str(t).lower()]

    # 3) Fall back to settings.json
    budget = get_settings().get('statusLineTokenBudget')
    if budget:
        return int(budget)

    # 4) Default
    return 44000


EFFORT_COLORS = {'low': CN, 'medium': Y, 'high': RD, 'max': RD}


def build(d, live):
    model = (d.get('model') or {}).get('display_name') or (d.get('model') or {}).get('id') or '--'
    ctx = d.get('context_window') or {}

    ctx_pct = round(ctx.get('used_percentage') or 0)
    ctx_size = ctx.get('context_window_size') or 200000

    # ── Rate limits from account ── (all three buckets — desktop app shows the worst)
    buckets = {
        'five_hour':      get_rate_limit(d, live, 'five_hour'),
        'seven_day':      get_rate_limit(d, live, 'seven_day'),
        'seven_day_opus': get_rate_limit(d, live, 'seven_day_opus'),
    }
    bucket_labels = {'five_hour': '5h', 'seven_day': '7d', 'seven_day_opus': 'Opus 7d'}

    # ── Assemble ──
    parts = []

    # Model + effort
    effort = get_effort(d)
    if effort:
        ec = EFFORT_COLORS.get(effort, W)
        parts.append(f'{B}{MG}{model}{R} {ec}{effort}{R}')
    else:
        parts.append(f'{B}{MG}{model}{R}')

    # Context bar — reads context_window_size from stdin (auto-adjusts for 200k/1M)
    c_col = color_pct(ctx_pct)
    parts.append(f'{c_col}{bar(ctx_pct, 8)}{R} {c_col}{ctx_pct}%{R} {D}of {fmt(ctx_size)}{R}')

    # Pick the dominant (highest-utilization) bucket as the headline — matches what
    # the Claude desktop app surfaces, since *any* of these three windows can throttle.
    present = {k: v for k, v in buckets.items() if v is not None}
    if present:
        head_key = max(present, key=lambda k: present[k]['pct_raw'])
        five_hr = present[head_key]
        fc = color_pct(five_hr['pct'])
        rs = fmt_reset(five_hr['reset'])
        budget = get_token_budget(live)
        used_tok = round(budget * five_hr['pct_raw'] / 100)
        label = bucket_labels[head_key]
        s = f'{fc}{fmt(used_tok)}{R}{D}/{R}{W}{fmt(budget)}{R} {fc}{bar(five_hr["pct"], 8)}{R} {fc}{B}{five_hr["pct"]}%{R} {D}{label}{R}'
        if five_hr['pct'] >= 100:
            s = f'{RD}{B}\u26a0{R} {s}'
        if rs:
            s += f' {D}({rs}){R}'
        parts.append(s)

        # Compact summary of the other two buckets so no window is hidden
        others = []
        for k in ('five_hour', 'seven_day', 'seven_day_opus'):
            if k == head_key or k not in present:
                continue
            b = present[k]
            oc = color_pct(b['pct'])
            others.append(f'{D}{bucket_labels[k]}{R} {oc}{b["pct"]}%{R}')
        if others:
            parts.append(' '.join(others))

    # Live dot
    if live and live.get('_ts'):
        age = time.time() - live['_ts']
        if age < CACHE_TTL:
            dot = f'{G}\u25cf{R}'
        else:
            dot = f'{D}\u25cf{R}'
        parts.append(dot)

    return f' {SEP} '.join(parts) + '\n'


def main():
    data = sys.stdin.read()
    try:
        session = json.loads(data)
        live = get_live_usage()
        sys.stdout.write(build(session, live))
    except Exception:
        sys.stdout.write(f'{D}token-tracker: waiting\u2026{R}\n')


if __name__ == '__main__':
    main()
