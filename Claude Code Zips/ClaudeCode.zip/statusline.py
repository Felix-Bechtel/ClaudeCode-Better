#!/usr/bin/env python3
"""token-tracker v7 — account-synced usage with real-time updates.
Shows account-level token usage from Claude API, session cost, context window.
"""

import json
import os
import sys
import subprocess
import time
from pathlib import Path

# ── Colors ──
R = '\x1b[0m'; B = '\x1b[1m'; D = '\x1b[2m'
W = '\x1b[97m'; CN = '\x1b[36m'; G = '\x1b[32m'
Y = '\x1b[33m'; RD = '\x1b[91m'; MG = '\x1b[35m'
BL = '\x1b[34m'; GY = '\x1b[90m'
SEP = f'{GY}\u2502{R}'

# ── Cache (10s TTL for near real-time) ──
CACHE_FILE = Path(os.environ.get('TMPDIR', '/tmp')) / 'token-tracker-usage.json'
CACHE_TTL = 10


def get_oauth_token():
    # 1) Env var
    env_tok = os.environ.get('CLAUDE_CODE_OAUTH_TOKEN')
    if env_tok:
        try:
            env = json.loads(env_tok)
            return env.get('accessToken') or (env.get('claudeAiOauth') or {}).get('accessToken')
        except (json.JSONDecodeError, TypeError):
            if env_tok.startswith('sk-ant-'):
                return env_tok
    # 2) macOS Keychain
    if sys.platform == 'darwin':
        try:
            raw = subprocess.run(
                ['security', 'find-generic-password', '-s', 'Claude Code-credentials', '-w'],
                capture_output=True, text=True, timeout=2
            ).stdout.strip()
            if raw:
                c = json.loads(raw)
                return (c.get('claudeAiOauth') or {}).get('accessToken') or c.get('accessToken')
        except Exception:
            pass
    # 3) Credentials file
    config_dir = Path(os.environ.get('CLAUDE_CONFIG_DIR', Path.home() / '.claude'))
    try:
        c = json.loads((config_dir / '.credentials.json').read_text())
        return (c.get('claudeAiOauth') or {}).get('accessToken') or c.get('accessToken')
    except Exception:
        pass
    return None


def get_live_usage():
    # Fast path: cache hit (valid data only)
    try:
        cached = json.loads(CACHE_FILE.read_text())
        if cached.get('_ts') and not cached.get('error') and time.time() - cached['_ts'] < CACHE_TTL:
            return cached
    except Exception:
        pass

    # Slow path: curl API (max 2s)
    token = get_oauth_token()
    if not token:
        return None
    try:
        result = subprocess.run(
            ['curl', '-s', '--max-time', '2',
             '-H', 'Accept: application/json',
             '-H', f'Authorization: Bearer {token}',
             '-H', 'anthropic-beta: oauth-2025-04-20',
             'https://api.anthropic.com/api/oauth/usage'],
            capture_output=True, text=True, timeout=3
        )
        out = result.stdout.strip()
        if out:
            data = json.loads(out)
            if data.get('error'):
                pass  # don't cache error responses
            else:
                data['_ts'] = time.time()
                try:
                    CACHE_FILE.write_text(json.dumps(data))
                except Exception:
                    pass
                return data
    except Exception:
        pass

    # Stale cache fallback (valid data only)
    try:
        cached = json.loads(CACHE_FILE.read_text())
        if not cached.get('error'):
            return cached
    except Exception:
        pass
    return None


def fmt(n):
    if n >= 1e6:
        return f'{n/1e6:.1f}M'
    if n >= 1e3:
        return f'{n/1e3:.1f}k'
    return str(n)


def color_pct(p):
    if p < 30: return G
    if p < 50: return CN
    if p < 75: return Y
    return RD


def bar(p, w=10):
    f = min(round(p / 100 * w), w)
    return '\u2588' * f + '\u2591' * (w - f)


def fmt_reset(r):
    if not r:
        return ''
    if isinstance(r, str):
        from datetime import datetime
        try:
            ts = int(datetime.fromisoformat(r.replace('Z', '+00:00')).timestamp())
        except Exception:
            return ''
    else:
        ts = int(r)
    d = max(0, ts - int(time.time()))
    if d <= 0:
        return 'now'
    days = d // 86400
    h = (d % 86400) // 3600
    m = (d % 3600) // 60
    if days > 0:
        return f'{days}d {h}h'
    if h > 0:
        return f'{h}h {m}m'
    return f'{m}m'


def get_rate_limit(d, live, key):
    """Get rate limit data from live API first, then stdin fallback."""
    # Prefer live API data
    if live and live.get(key):
        p = live[key].get('utilization')
        if p is not None:
            p = float(p)
            if 0 < p <= 1:
                p *= 100
            p = round(p)
            return {'pct': p, 'left': 100 - p, 'reset': live[key].get('resets_at')}

    # Fallback to stdin rate limits
    rl = (d.get('rate_limits') or {}).get(key) or {}
    p = rl.get('used_percentage')
    if p is None:
        p = rl.get('utilization')
        if p is not None:
            p = float(p)
            if 0 < p <= 1:
                p *= 100
    if p is not None:
        p = round(float(p))
        return {'pct': p, 'left': 100 - p, 'reset': rl.get('resets_at')}

    return None


def get_settings():
    """Read settings.json once, cached for the process lifetime."""
    if not hasattr(get_settings, '_cache'):
        try:
            get_settings._cache = json.loads(Path(Path.home() / '.claude' / 'settings.json').read_text())
        except Exception:
            get_settings._cache = {}
    return get_settings._cache


def get_effort(d=None):
    """Read effort level from session stdin (live), then settings.json fallback."""
    # 1) Check stdin session data — output_style.name reflects live effort
    if d:
        style = (d.get('output_style') or {}).get('name')
        if style and style != 'default':
            return style
    # 2) Fall back to settings.json
    return get_settings().get('effortLevel')


TIER_BUDGETS = {
    'pro': 44000,
    '5x': 88000,
    'max_5x': 88000,
    '20x': 220000,
    'max_20x': 220000,
}


def get_token_budget(live):
    """Detect token budget from API tier, settings.json fallback, or default 44k."""
    # 1) Check live API data for tier/plan info
    if live:
        for key in ('plan', 'tier', 'subscription', 'plan_tier'):
            tier = live.get(key)
            if tier and str(tier).lower() in TIER_BUDGETS:
                return TIER_BUDGETS[str(tier).lower()]
        # Check nested account info
        acct = live.get('account') or {}
        for key in ('plan', 'tier', 'subscription'):
            tier = acct.get(key)
            if tier and str(tier).lower() in TIER_BUDGETS:
                return TIER_BUDGETS[str(tier).lower()]
    # 2) Fall back to settings.json
    budget = get_settings().get('statusLineTokenBudget')
    if budget:
        return int(budget)
    # 3) Default
    return 44000


EFFORT_COLORS = {'low': CN, 'medium': Y, 'high': RD, 'max': RD}


def build(d, live):
    model = (d.get('model') or {}).get('display_name') or (d.get('model') or {}).get('id') or '--'
    ctx = d.get('context_window') or {}

    ctx_pct = round(ctx.get('used_percentage') or 0)
    ctx_size = ctx.get('context_window_size') or 200000

    # ── Rate limits from account ──
    five_hr = get_rate_limit(d, live, 'five_hour')

    # ── Assemble ──
    parts = []

    # Model + effort (live from session, fallback to settings.json)
    effort = get_effort(d)
    if effort:
        ec = EFFORT_COLORS.get(effort, W)
        parts.append(f'{B}{MG}{model}{R} {ec}{effort}{R}')
    else:
        parts.append(f'{B}{MG}{model}{R}')

    # Context bar
    c_col = color_pct(ctx_pct)
    parts.append(f'{c_col}{bar(ctx_pct, 8)}{R} {c_col}{ctx_pct}%{R} {D}of {fmt(ctx_size)}{R}')

    # 5-hour account usage with token count
    if five_hr:
        fc = color_pct(five_hr['pct'])
        rs = fmt_reset(five_hr['reset'])
        budget = get_token_budget(live)
        used_tok = round(budget * five_hr['pct'] / 100)
        s = f'{fc}{fmt(used_tok)}{R}{D}/{R}{W}{fmt(budget)}{R} {fc}{bar(five_hr["pct"], 8)}{R} {fc}{B}{five_hr["pct"]}%{R} {D}5h{R}'
        if five_hr['pct'] >= 100:
            s = f'{RD}{B}\u26a0{R} {s}'
        if rs:
            s += f' {D}({rs}){R}'
        parts.append(s)

    # Live dot
    if live and live.get('_ts'):
        age = time.time() - live['_ts']
        if age < CACHE_TTL:
            dot = f'{G}\u25cf{R}'
        else:
            dot = f'{D}\u25cf{R}'
        parts.append(dot)

    return f' {SEP} '.join(parts) + '\n'


def main():
    data = sys.stdin.read()
    try:
        session = json.loads(data)
        live = get_live_usage()
        sys.stdout.write(build(session, live))
    except Exception:
        sys.stdout.write(f'{D}token-tracker: waiting\u2026{R}\n')


if __name__ == '__main__':
    main()
