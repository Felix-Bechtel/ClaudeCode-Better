#!/usr/bin/env python3
"""token-tracker v8 — account-synced usage with keychain tier detection.
Shows account-level token usage, session cost, context window, effort level.
"""

import json
import os
import sys
import subprocess
import time
from pathlib import Path

# ── Colors ──
R = '\x1b[0m'; B = '\x1b[1m'; D = '\x1b[2m'
W = '\x1b[97m'; CN = '\x1b[36m'; G = '\x1b[32m'
Y = '\x1b[33m'; RD = '\x1b[91m'; MG = '\x1b[35m'
BL = '\x1b[34m'; GY = '\x1b[90m'
SEP = f'{GY}\u2502{R}'

# ── Cache (3s TTL for live-feeling refresh; matches statusLine.refreshInterval) ──
CACHE_FILE = Path(os.environ.get('TMPDIR', '/tmp')) / 'token-tracker-usage.json'
ERROR_FILE = Path(os.environ.get('TMPDIR', '/tmp')) / 'token-tracker-error.json'
EFFORT_FILE = Path(os.environ.get('TMPDIR', '/tmp')) / 'claude-effort'
CACHE_TTL = 3
ERROR_BACKOFF = 60  # seconds to skip live API after a rate-limit/error response


def get_keychain_credentials():
    """Read Claude Code OAuth credentials from macOS Keychain (cached per process).
    The keychain can hold multiple entries under service 'Claude Code-credentials'
    (one per account). Default lookup returns the first one, which is often empty
    ('unknown' account). Enumerate accounts and pick the first with a real token.
    """
    if not hasattr(get_keychain_credentials, '_cache'):
        get_keychain_credentials._cache = {}
        if sys.platform == 'darwin':
            # Accounts to try, in order of preference. Shell login name is the
            # most common real entry on macOS.
            candidates = [os.environ.get('USER') or '', 'claude', 'claudeai', 'anthropic']
            # Also try the default (no -a flag) as fallback
            candidates.append(None)
            for acct in candidates:
                try:
                    cmd = ['security', 'find-generic-password', '-s', 'Claude Code-credentials', '-w']
                    if acct:
                        cmd += ['-a', acct]
                    raw = subprocess.run(cmd, capture_output=True, text=True, timeout=2).stdout.strip()
                    if not raw:
                        continue
                    parsed = json.loads(raw)
                    co = parsed.get('claudeAiOauth') or {}
                    if co.get('accessToken'):
                        get_keychain_credentials._cache = co
                        break
                except Exception:
                    continue
    return get_keychain_credentials._cache


def get_oauth_token():
    # 1) Env var
    env_tok = os.environ.get('CLAUDE_CODE_OAUTH_TOKEN')
    if env_tok:
        try:
            env = json.loads(env_tok)
            return env.get('accessToken') or (env.get('claudeAiOauth') or {}).get('accessToken')
        except (json.JSONDecodeError, TypeError):
            if env_tok.startswith('sk-ant-'):
                return env_tok
    # 2) Keychain (reuse cached credentials)
    creds = get_keychain_credentials()
    if creds.get('accessToken'):
        return creds['accessToken']
    # 3) Credentials file
    config_dir = Path(os.environ.get('CLAUDE_CONFIG_DIR', Path.home() / '.claude'))
    try:
        c = json.loads((config_dir / '.credentials.json').read_text())
        return (c.get('claudeAiOauth') or {}).get('accessToken') or c.get('accessToken')
    except Exception:
        pass
    return None


def get_live_usage():
    # Fast path: cache hit (valid data only)
    try:
        cached = json.loads(CACHE_FILE.read_text())
        if cached.get('_ts') and not cached.get('error') and time.time() - cached['_ts'] < CACHE_TTL:
            return cached
    except Exception:
        pass

    # Backoff: if a recent API call failed/errored, skip the network for
    # ERROR_BACKOFF seconds. Without this, a rate-limit response sets up an
    # exact re-call every refreshInterval (1s) — which re-triggers the limiter.
    try:
        err = json.loads(ERROR_FILE.read_text())
        if err.get('_ts') and time.time() - err['_ts'] < ERROR_BACKOFF:
            # Use stale-but-valid cache while we back off, if there is one.
            try:
                cached = json.loads(CACHE_FILE.read_text())
                if (not cached.get('error') and cached.get('_ts')
                        and (time.time() - cached['_ts']) < 600):
                    return cached
            except Exception:
                pass
            return None
    except Exception:
        pass

    # Slow path: curl API (max 2s)
    token = get_oauth_token()
    if not token:
        return None
    failed = False
    try:
        result = subprocess.run(
            ['curl', '-s', '--max-time', '2',
             '-H', 'Accept: application/json',
             '-H', f'Authorization: Bearer {token}',
             '-H', 'anthropic-beta: oauth-2025-04-20',
             'https://api.anthropic.com/api/oauth/usage'],
            capture_output=True, text=True, timeout=3
        )
        out = result.stdout.strip()
        if out:
            data = json.loads(out)
            if data.get('error'):
                failed = True
            else:
                data['_ts'] = time.time()
                try:
                    CACHE_FILE.write_text(json.dumps(data))
                    ERROR_FILE.unlink(missing_ok=True)
                except Exception:
                    pass
                return data
        else:
            failed = True
    except Exception:
        failed = True

    if failed:
        try:
            ERROR_FILE.write_text(json.dumps({'_ts': time.time()}))
        except Exception:
            pass

    # Stale cache fallback — only if less than 60s old (prefer stdin over ancient cache)
    try:
        cached = json.loads(CACHE_FILE.read_text())
        if not cached.get('error') and cached.get('_ts') and (time.time() - cached['_ts']) < 60:
            return cached
    except Exception:
        pass
    return None


def fmt(n):
    if n >= 1e6:
        return f'{n/1e6:.1f}M'
    if n >= 1e3:
        return f'{n/1e3:.1f}k'
    return str(n)


def color_pct(p):
    if p < 30: return G
    if p < 50: return CN
    if p < 75: return Y
    return RD


def bar(p, w=10):
    f = min(round(p / 100 * w), w)
    return '\u2588' * f + '\u2591' * (w - f)


def fmt_reset(r):
    if not r:
        return ''
    if isinstance(r, str):
        from datetime import datetime
        try:
            ts = int(datetime.fromisoformat(r.replace('Z', '+00:00')).timestamp())
        except Exception:
            return ''
    else:
        ts = int(r)
    d = max(0, ts - int(time.time()))
    if d <= 0:
        return 'now'
    days = d // 86400
    h = (d % 86400) // 3600
    m = (d % 3600) // 60
    if days > 0:
        return f'{days}d {h}h'
    if h > 0:
        return f'{h}h {m}m'
    return f'{m}m'


def _to_float(v):
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def _norm_bucket(raw):
    """Normalize a rate-limit bucket dict into {pct, reset, used, limit}.
    Some APIs send 0-1 fractions; only rescale when strictly < 1 to avoid
    mistaking an integer "1" (= 1%) or a literal "1.0" (= 1%) for "100%".
    `used` and `limit` are returned when the source provides authoritative
    token counts so the headline can show real numbers instead of multiplying
    a percentage by the user's override budget (which inflates the count when
    the override doesn't match the real ceiling)."""
    if not raw:
        return None
    p = _to_float(raw.get('used_percentage'))
    if p is None:
        p = _to_float(raw.get('utilization'))
    used = _to_float(raw.get('used') or raw.get('used_tokens') or raw.get('tokens_used'))
    limit = _to_float(raw.get('limit') or raw.get('total') or raw.get('total_tokens')
                      or raw.get('budget') or raw.get('cap'))
    remaining = _to_float(raw.get('remaining') or raw.get('remaining_tokens'))
    if used is None and limit is not None and remaining is not None:
        used = max(0.0, limit - remaining)
    if p is None and used is not None and limit and limit > 0:
        p = (used / limit) * 100.0
    if p is None:
        return None
    if 0 < p < 1:
        p *= 100
    p = max(0.0, min(p, 100.0))
    return {
        'pct': round(p),
        'pct_raw': p,
        'reset': raw.get('resets_at'),
        'used': used,
        'limit': limit,
    }


# Aliases for each logical bucket — different sources use different keys.
BUCKET_ALIASES = {
    'five_hour':       ('five_hour', 'fiveHour', '5h', 'session', 'rolling_5h'),
    'seven_day':       ('seven_day', 'sevenDay', '7d', 'weekly', 'rolling_7d'),
    'seven_day_opus':  ('seven_day_opus', 'sevenDayOpus', '7d_opus', 'weekly_opus',
                        'opus_weekly', 'rolling_7d_opus'),
}


def get_rate_limit(d, live, logical_key):
    """Get rate limit data for a logical bucket.

    Stdin is canonical (Claude harness sends fresh values every tick); the live
    OAuth API is only a fallback when stdin doesn't have the bucket. Reversing
    this caused a flicker: a stale/anomalous live value (e.g. 100% for 7d)
    would override the real stdin value for up to 30s every refresh cycle.
    """
    aliases = BUCKET_ALIASES.get(logical_key, (logical_key,))

    # 1) Prefer stdin — always fresh, comes from the harness this tick.
    rl = d.get('rate_limits') or {}
    for k in aliases:
        b = _norm_bucket(rl.get(k))
        if b:
            return b

    # 2) Fall back to the live OAuth API cache (top level or nested).
    if live:
        for k in aliases:
            b = _norm_bucket(live.get(k))
            if b:
                return b
        rl_live = live.get('rate_limits') or {}
        for k in aliases:
            b = _norm_bucket(rl_live.get(k))
            if b:
                return b
    return None


def get_settings():
    """Read settings.json once per process. Invalidate the live-usage cache
    when settings.json mtime changes so footer reflects plan switches fast."""
    if not hasattr(get_settings, '_cache'):
        settings_path = Path.home() / '.claude' / 'settings.json'
        try:
            mtime = settings_path.stat().st_mtime
        except Exception:
            mtime = 0
        # Drop the API cache if settings were touched after it was written.
        try:
            cached = json.loads(CACHE_FILE.read_text())
            if cached.get('_ts') and mtime > cached['_ts']:
                CACHE_FILE.unlink()
        except Exception:
            pass
        try:
            get_settings._cache = json.loads(settings_path.read_text())
        except Exception:
            get_settings._cache = {}
    return get_settings._cache


def get_effort(d=None):
    """Read effort level: session temp file > stdin output_style > settings.json."""
    # 1) Session temp file (written by UserPromptSubmit hook on /effort)
    try:
        level = EFFORT_FILE.read_text().strip().lower()
        if level in ('low', 'medium', 'high', 'max'):
            return level
    except Exception:
        pass
    # 2) Check stdin session data — output_style.name
    if d:
        style = (d.get('output_style') or {}).get('name')
        if style and style != 'default':
            return style
    # 3) Fall back to settings.json
    return get_settings().get('effortLevel')


# ── Tier detection from keychain credentials ──
TIER_MAP = {
    'default_claude_pro': 44000,
    'pro': 44000,
    'default_claude_max_5x': 88000,
    'max_5x': 88000,
    '5x': 88000,
    'default_claude_max_20x': 220000,
    'max_20x': 220000,
    '20x': 220000,
}


def get_plan_name(budget):
    """Pretty plan label.

    An explicit selection made with `! plans` (statusLinePlanName) always wins
    — the user chose that badge on purpose. Otherwise infer from the budget
    number we're actually about to display, then fall back to keychain tier.
    """
    s = get_settings()
    if s.get('statusLinePlanName'):
        return str(s['statusLinePlanName'])
    if budget == 44000:
        return 'Pro'
    if budget == 88000:
        return 'Max 5x'
    if budget == 220000:
        return 'Max 20x'
    creds = get_keychain_credentials()
    tier = (creds.get('rateLimitTier') or '').lower()
    if tier in ('default_claude_pro', 'pro'):
        return 'Pro'
    if tier in ('default_claude_max_5x', 'max_5x', '5x'):
        return 'Max 5x'
    if tier in ('default_claude_max_20x', 'max_20x', '20x'):
        return 'Max 20x'
    sub = (creds.get('subscriptionType') or '').lower()
    if sub == 'pro':
        return 'Pro'
    if sub == 'max':
        return 'Max'
    return ''


def get_token_budget(live):
    """Detect token budget: explicit override > keychain tier > live API > default."""
    # 0) Explicit override in settings.json — wins over everything so the user
    # can lock the displayed budget to their actual plan (e.g. Max 5x = 88000)
    # when keychain/live detection is flaky. Set via `! plan <pro|5x|20x>`.
    override = get_settings().get('statusLineTokenBudget')
    if override:
        return int(override)
    # 1) Keychain credentials — most reliable source
    creds = get_keychain_credentials()
    tier = (creds.get('rateLimitTier') or '').lower()
    if tier in TIER_MAP:
        return TIER_MAP[tier]
    # Infer from subscriptionType
    sub = (creds.get('subscriptionType') or '').lower()
    if sub == 'max':
        # Default max to 5x if specific tier not identified
        return 88000
    if sub == 'pro':
        return 44000

    # 2) Check live API data for tier/plan info
    if live:
        for key in ('plan', 'tier', 'subscription', 'plan_tier'):
            t = live.get(key)
            if t and str(t).lower() in TIER_MAP:
                return TIER_MAP[str(t).lower()]
        acct = live.get('account') or {}
        for key in ('plan', 'tier', 'subscription'):
            t = acct.get(key)
            if t and str(t).lower() in TIER_MAP:
                return TIER_MAP[str(t).lower()]

    # 3) Default — explicit override is already handled at step 0 above.
    return 44000


EFFORT_COLORS = {'low': CN, 'medium': Y, 'high': RD, 'max': RD}


def build(d, live):
    model = (d.get('model') or {}).get('display_name') or (d.get('model') or {}).get('id') or '--'
    ctx = d.get('context_window') or {}

    ctx_pct = round(ctx.get('used_percentage') or 0)
    ctx_size = ctx.get('context_window_size') or 200000

    # ── Rate limits from account ── (all three buckets — desktop app shows the worst)
    buckets = {
        'five_hour':      get_rate_limit(d, live, 'five_hour'),
        'seven_day':      get_rate_limit(d, live, 'seven_day'),
        'seven_day_opus': get_rate_limit(d, live, 'seven_day_opus'),
    }
    bucket_labels = {'five_hour': '5h', 'seven_day': '7d', 'seven_day_opus': 'Opus 7d'}

    # ── Assemble ──
    parts = []

    # Model + effort
    effort = get_effort(d)
    if effort:
        ec = EFFORT_COLORS.get(effort, W)
        parts.append(f'{B}{MG}{model}{R} {ec}{effort}{R}')
    else:
        parts.append(f'{B}{MG}{model}{R}')

    # Context bar — reads context_window_size from stdin (auto-adjusts for 200k/1M)
    c_col = color_pct(ctx_pct)
    parts.append(f'{c_col}{bar(ctx_pct, 8)}{R} {c_col}{ctx_pct}%{R} {D}of {fmt(ctx_size)}{R}')

    # Pick the dominant (highest-utilization) bucket as the headline — matches what
    # the Claude desktop app surfaces, since *any* of these three windows can throttle.
    present = {k: v for k, v in buckets.items() if v is not None}
    if present:
        # Always headline the 5h bucket (live token-refresh countdown).
        # Other windows (7d, Opus 7d) are summarized after, never promoted.
        head_key = 'five_hour' if 'five_hour' in present else next(iter(present))
        five_hr = present[head_key]
        fc = color_pct(five_hr['pct'])
        rs = fmt_reset(five_hr['reset'])
        # Prefer authoritative numbers from the source: if the bucket reports
        # a real `used` and `limit`, show those directly. Otherwise fall back
        # to the user's plan override and compute used = budget * pct. The
        # latter gets "thrown off" when the override doesn't match the real
        # ceiling — e.g. user sets Max 20x (220k) while keychain is still
        # Max 5x (88k), so a 35% bucket would falsely render as 77k of 220k
        # instead of 31k of 88k.
        api_used = five_hr.get('used')
        api_limit = five_hr.get('limit')
        if api_used is not None and api_limit and api_limit > 0:
            used_tok = round(api_used)
            budget = int(api_limit)
        else:
            budget = get_token_budget(live)
            used_tok = round(budget * five_hr['pct_raw'] / 100)
        label = bucket_labels[head_key]
        plan_name = get_plan_name(budget)
        plan_tag = f'{BL}{plan_name}{R} ' if plan_name else ''
        s = f'{plan_tag}{fc}{bar(five_hr["pct"], 8)}{R} {fc}{B}{five_hr["pct"]}%{R} {D}{label}{R}'
        if five_hr['pct'] >= 100:
            s = f'{RD}{B}\u26a0{R} {s}'
        if rs:
            s += f' {D}({rs}){R}'
        parts.append(s)

        # Compact summary of the other two buckets so no window is hidden
        others = []
        for k in ('five_hour', 'seven_day', 'seven_day_opus'):
            if k == head_key or k not in present:
                continue
            b = present[k]
            oc = color_pct(b['pct'])
            others.append(f'{D}{bucket_labels[k]}{R} {oc}{b["pct"]}%{R}')
        if others:
            parts.append(' '.join(others))

    # Live dot
    if live and live.get('_ts'):
        age = time.time() - live['_ts']
        if age < CACHE_TTL:
            dot = f'{G}\u25cf{R}'
        else:
            dot = f'{D}\u25cf{R}'
        parts.append(dot)

    return f' {SEP} '.join(parts) + '\n'


def main():
    data = sys.stdin.read()
    try:
        session = json.loads(data)
        live = get_live_usage()
        sys.stdout.write(build(session, live))
    except Exception:
        sys.stdout.write(f'{D}token-tracker: waiting\u2026{R}\n')


if __name__ == '__main__':
    main()
