# Claude Code Settings Pack — Info

A portable bundle of settings, commands, status line, and plugins for Claude Code.

## Quick Start

Run commands in Claude Code by typing `! <command>` in the chat prompt. For example: `! buddy stats`

## Quick Setup

1. Unzip and give `claude-code-setup.md` to a new Claude Code instance
2. Tell it: "Apply the settings from this file"
3. Add your own API key, plugins, and MCP servers to `settings.json` as needed

## What's Included

| File | Description |
|------|-------------|
| `settings.json` | Main config — model, hooks, permissions, status line, effort level |
| `statusline.py` | Token tracker with account-synced 5h budget, context window, effort display |
| `commands/` | Slash commands (see below) |
| `Info.md` | This file |

## Commands

Copy the `commands/` folder to `~/.claude/commands/` to use these as slash commands.

### `/just-do-it`
Skips all confirmation prompts for the rest of the session. Claude will apply every edit, install, and change immediately without asking. Destructive actions still get a brief mention before proceeding.

### `/status`
Runs a quick status check showing your current model, permissions mode, installed plugins, available commands, keep-awake state, and statusline presence.

### `/verify-settings`
Runs a full health check on your Claude Code setup: symlinks, settings.json keys, buddy collection, CLAUDE.md, commands, status line, installed plugins, and zip backups. Reports every check with a pass/fail marker and a final summary.

### `/keep-awake`
Prevents macOS from sleeping while Claude works on a long task. Runs `caffeinate` in the background, tied to the current shell so it auto-cleans up when Claude exits.

## Session Start

At the start of every new conversation:
1. The settings pack and all installed plugins **auto-update silently in the background** — no prompt, updates load next session
2. Claude asks: **"Would you like to use just-do-it? (yes/no)"** — enables no-confirmation mode

After answering, Claude continues with whatever you originally typed.

## Status Line

The footer bar shows real-time account-synced data:
- **Model + Effort** — e.g. "Opus 4.6 high"
- **Context window** — usage bar with percentage and size (200k or 1M)
- **Plan badge** — your plan (Pro / Max 5x / Max 20x / custom) shown next to the budget; pick it with `! plans` (aesthetic only — changes the badge, nothing else)
- **5h token budget** — tokens used/total with percentage bar, synced to your Claude account
- **Reset timer** — time until your 5h budget resets
- **Live dot** — green when API data is fresh

Token budget adjusts based on your subscription tier:
- Pro: 44k tokens / 5h
- Max 5x: 88k tokens / 5h
- Max 20x: 220k tokens / 5h

## Settings Highlights

- **Model**: `claude-opus-4-6`
- **Permissions**: bypass mode (no prompts)
- **Hooks**: PreCompact (saves context to memory), Stop (reminder to save decisions)
- **Effort Level**: max
