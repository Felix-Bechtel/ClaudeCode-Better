#!/usr/bin/env node
// token-tracker v8 — Node.js version matching Python statusline.py v8
// Keychain tier detection, effort tracking, context auto-switch.

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

// ── Colors ──
const R = '\x1b[0m', B = '\x1b[1m', D = '\x1b[2m';
const W = '\x1b[97m', CN = '\x1b[36m', G = '\x1b[32m';
const Y = '\x1b[33m', RD = '\x1b[91m', MG = '\x1b[35m';
const BL = '\x1b[34m', GY = '\x1b[90m';
const SEP = `${GY}│${R}`;

// ── Cache ──
const CACHE_FILE = path.join(os.tmpdir(), 'token-tracker-usage.json');
const ERROR_FILE = path.join(os.tmpdir(), 'token-tracker-error.json');
const EFFORT_FILE = path.join(os.tmpdir(), 'claude-effort');
const CACHE_TTL = 10_000;
const ERROR_BACKOFF = 60_000;

// ── Tier detection ──
const TIER_MAP = {
  default_claude_pro: 44000,
  pro: 44000,
  default_claude_max_5x: 88000,
  max_5x: 88000,
  '5x': 88000,
  default_claude_max_20x: 220000,
  max_20x: 220000,
  '20x': 220000,
};

const EFFORT_COLORS = { low: CN, medium: Y, high: RD, max: RD };

// ── Read stdin ──
let input = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => { input += chunk; });
process.stdin.on('end', () => {
  try {
    const session = JSON.parse(input);
    const live = getLiveUsage();
    process.stdout.write(build(session, live));
  } catch {
    process.stdout.write(`${D}token-tracker: waiting…${R}\n`);
  }
});

// ══════════════════════════════════════════
// All functions below are SYNCHRONOUS
// ══════════════════════════════════════════

let _keychainCache = null;
function getKeychainCredentials() {
  if (_keychainCache !== null) return _keychainCache;
  _keychainCache = {};
  if (process.platform === 'darwin') {
    try {
      const raw = execSync(
        'security find-generic-password -s "Claude Code-credentials" -w 2>/dev/null',
        { encoding: 'utf8', timeout: 2000, stdio: ['pipe', 'pipe', 'pipe'] }
      ).trim();
      if (raw) _keychainCache = JSON.parse(raw).claudeAiOauth || {};
    } catch {}
  }
  return _keychainCache;
}

function getOAuthToken() {
  if (process.env.CLAUDE_CODE_OAUTH_TOKEN) {
    try {
      const env = JSON.parse(process.env.CLAUDE_CODE_OAUTH_TOKEN);
      return env.accessToken || env.claudeAiOauth?.accessToken || null;
    } catch {
      if (process.env.CLAUDE_CODE_OAUTH_TOKEN.startsWith('sk-ant-'))
        return process.env.CLAUDE_CODE_OAUTH_TOKEN;
    }
  }
  const creds = getKeychainCredentials();
  if (creds.accessToken) return creds.accessToken;
  const configDir = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
  try {
    const c = JSON.parse(fs.readFileSync(path.join(configDir, '.credentials.json'), 'utf8'));
    return c.claudeAiOauth?.accessToken || c.accessToken || null;
  } catch {}
  return null;
}

function getLiveUsage() {
  try {
    const cached = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
    if (cached._ts && !cached.error && Date.now() - cached._ts < CACHE_TTL) return cached;
  } catch {}

  // Backoff: skip the network for ERROR_BACKOFF ms after a failed call.
  try {
    const err = JSON.parse(fs.readFileSync(ERROR_FILE, 'utf8'));
    if (err._ts && Date.now() - err._ts < ERROR_BACKOFF) {
      try {
        const cached = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
        if (!cached.error && cached._ts && (Date.now() - cached._ts) < 600_000) return cached;
      } catch {}
      return null;
    }
  } catch {}

  const token = getOAuthToken();
  if (!token) return null;
  let failed = false;
  try {
    const out = execSync(
      `curl -s --max-time 2 -H "Accept: application/json" -H "Authorization: Bearer ${token}" -H "anthropic-beta: oauth-2025-04-20" "https://api.anthropic.com/api/oauth/usage"`,
      { encoding: 'utf8', timeout: 3000, stdio: ['pipe', 'pipe', 'pipe'] }
    ).trim();
    if (out) {
      const data = JSON.parse(out);
      if (data.error) {
        failed = true;
      } else {
        data._ts = Date.now();
        try { fs.writeFileSync(CACHE_FILE, JSON.stringify(data)); } catch {}
        try { fs.unlinkSync(ERROR_FILE); } catch {}
        return data;
      }
    } else {
      failed = true;
    }
  } catch {
    failed = true;
  }

  if (failed) {
    try { fs.writeFileSync(ERROR_FILE, JSON.stringify({ _ts: Date.now() })); } catch {}
  }

  // Stale cache fallback — only if < 60s old (prefer stdin over ancient cache)
  try {
    const cached = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
    if (!cached.error && cached._ts && (Date.now() - cached._ts) < 60_000) return cached;
  } catch {}
  return null;
}

let _settingsCache = null;
function getSettings() {
  if (_settingsCache !== null) return _settingsCache;
  try {
    _settingsCache = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.claude', 'settings.json'), 'utf8'));
  } catch {
    _settingsCache = {};
  }
  return _settingsCache;
}

function getEffort(d) {
  // 1) Session temp file (written by UserPromptSubmit hook)
  try {
    const level = fs.readFileSync(EFFORT_FILE, 'utf8').trim().toLowerCase();
    if (['low', 'medium', 'high', 'max'].includes(level)) return level;
  } catch {}
  // 2) stdin output_style
  const style = d?.output_style?.name;
  if (style && style !== 'default') return style;
  // 3) settings.json
  return getSettings().effortLevel || null;
}

function getPlanName(budget) {
  // Explicit selection via `! plans` always wins — the user chose that badge.
  const s = getSettings();
  if (s.statusLinePlanName) return String(s.statusLinePlanName);
  if (budget === 44000) return 'Pro';
  if (budget === 88000) return 'Max 5x';
  if (budget === 220000) return 'Max 20x';
  const creds = getKeychainCredentials();
  const tier = (creds.rateLimitTier || '').toLowerCase();
  if (['default_claude_pro', 'pro'].includes(tier)) return 'Pro';
  if (['default_claude_max_5x', 'max_5x', '5x'].includes(tier)) return 'Max 5x';
  if (['default_claude_max_20x', 'max_20x', '20x'].includes(tier)) return 'Max 20x';
  const sub = (creds.subscriptionType || '').toLowerCase();
  if (sub === 'pro') return 'Pro';
  if (sub === 'max') return 'Max';
  return '';
}

function getTokenBudget(live) {
  // 1) Keychain tier
  const creds = getKeychainCredentials();
  const tier = (creds.rateLimitTier || '').toLowerCase();
  if (TIER_MAP[tier]) return TIER_MAP[tier];
  const sub = (creds.subscriptionType || '').toLowerCase();
  if (sub === 'max') return 88000;
  if (sub === 'pro') return 44000;

  // 2) Live API
  if (live) {
    for (const key of ['plan', 'tier', 'subscription', 'plan_tier']) {
      const t = live[key];
      if (t && TIER_MAP[String(t).toLowerCase()]) return TIER_MAP[String(t).toLowerCase()];
    }
    const acct = live.account || {};
    for (const key of ['plan', 'tier', 'subscription']) {
      const t = acct[key];
      if (t && TIER_MAP[String(t).toLowerCase()]) return TIER_MAP[String(t).toLowerCase()];
    }
  }

  // 3) settings.json
  const budget = getSettings().statusLineTokenBudget;
  if (budget) return Number(budget);

  return 44000;
}

function getRateLimit(d, live, key) {
  // Stdin is canonical; live API is only a fallback (mirrors statusline.py).
  function norm(rl) {
    if (!rl) return null;
    let p = rl.used_percentage ?? rl.utilization;
    let used = rl.used ?? rl.used_tokens ?? rl.tokens_used;
    const limit = rl.limit ?? rl.total ?? rl.total_tokens ?? rl.budget ?? rl.cap;
    const remaining = rl.remaining ?? rl.remaining_tokens;
    if (used == null && limit != null && remaining != null) used = Math.max(0, limit - remaining);
    if (p == null && used != null && limit) p = (used / limit) * 100;
    if (p == null) return null;
    p = Number(p);
    if (p > 0 && p < 1) p *= 100;
    p = Math.max(0, Math.min(p, 100));
    return { pct: Math.round(p), left: Math.round(100 - p), reset: rl.resets_at,
             used: used != null ? Number(used) : null,
             limit: limit != null ? Number(limit) : null };
  }
  const stdin = norm(d?.rate_limits?.[key]);
  if (stdin) return stdin;
  if (live) {
    return norm(live[key]) || norm(live.rate_limits?.[key]);
  }
  return null;
}

// ══════════════════════════════════════════
// Build the statusline string
// ══════════════════════════════════════════

function build(d, live) {
  const model = d.model?.display_name || d.model?.id || '--';
  const ctx = d.context_window || {};
  const ctxPct = Math.round(ctx.used_percentage || 0);
  const ctxSize = ctx.context_window_size || 200000;
  const fiveHr = getRateLimit(d, live, 'five_hour');

  const parts = [];

  // Model + effort
  const effort = getEffort(d);
  if (effort) {
    const ec = EFFORT_COLORS[effort] || W;
    parts.push(`${B}${MG}${model}${R} ${ec}${effort}${R}`);
  } else {
    parts.push(`${B}${MG}${model}${R}`);
  }

  // Context bar
  const cCol = colorPct(ctxPct);
  parts.push(`${cCol}${bar(ctxPct, 8)}${R} ${cCol}${ctxPct}%${R} ${D}of ${fmt(ctxSize)}${R}`);

  // 5-hour token budget — prefer authoritative API used/limit; else compute
  // used = override-budget * pct (which can mislead when override doesn't
  // match the real ceiling, but is the only signal when the source is silent).
  if (fiveHr) {
    const fc = colorPct(fiveHr.pct);
    const rs = fmtReset(fiveHr.reset);
    let budget, usedTok;
    if (fiveHr.used != null && fiveHr.limit && fiveHr.limit > 0) {
      usedTok = Math.round(fiveHr.used);
      budget = fiveHr.limit;
    } else {
      budget = getTokenBudget(live);
      usedTok = Math.round(budget * fiveHr.pct / 100);
    }
    const planName = getPlanName(budget);
    const planTag = planName ? `${BL}${planName}${R} ` : '';
    let s = `${planTag}${fc}${fmt(usedTok)}${R}${D}/${R}${W}${fmt(budget)}${R} ${fc}${bar(fiveHr.pct, 8)}${R} ${fc}${B}${fiveHr.pct}%${R} ${D}5h${R}`;
    if (fiveHr.pct >= 100) s = `${RD}${B}⚠${R} ${s}`;
    if (rs) s += ` ${D}(${rs})${R}`;
    parts.push(s);
  }

  // Live dot
  if (live && live._ts) {
    parts.push((Date.now() - live._ts) < CACHE_TTL ? `${G}●${R}` : `${D}●${R}`);
  }

  return parts.join(` ${SEP} `) + '\n';
}

function fmt(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(n);
}
function colorPct(p) { return p < 30 ? G : p < 50 ? CN : p < 75 ? Y : RD; }
function bar(p, w) {
  const f = Math.min(Math.round((p / 100) * w), w);
  return '█'.repeat(f) + '░'.repeat(w - f);
}
function fmtReset(r) {
  if (!r) return '';
  const ts = typeof r === 'string' ? Math.floor(new Date(r).getTime() / 1000) : Number(r);
  const d = Math.max(0, ts - Math.floor(Date.now() / 1000));
  if (d <= 0) return 'now';
  const days = Math.floor(d / 86400), h = Math.floor((d % 86400) / 3600), m = Math.floor((d % 3600) / 60);
  if (days > 0) return `${days}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}
