#!/usr/bin/env node
// token-tracker v6 — event-based stdin (proven working) + sync API via curl
// No async/await anywhere. Fast cache reads, 2s max curl on cache miss.

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

// ── Colors ──
const R = '\x1b[0m', B = '\x1b[1m', D = '\x1b[2m';
const W = '\x1b[97m', CN = '\x1b[36m', G = '\x1b[32m';
const Y = '\x1b[33m', RD = '\x1b[91m', MG = '\x1b[35m';
const BL = '\x1b[34m', GY = '\x1b[90m';
const SEP = `${GY}│${R}`;

// ── Cache ──
const CACHE_FILE = path.join(os.tmpdir(), 'token-tracker-usage.json');
const CACHE_TTL = 30_000;

// ── Read stdin the way Claude Code expects ──
let input = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => { input += chunk; });
process.stdin.on('end', () => {
  try {
    const session = JSON.parse(input);
    const live = getLiveUsage();
    process.stdout.write(build(session, live));
  } catch (e) {
    process.stdout.write(`${D}token-tracker: waiting…${R}\n`);
  }
});

// ══════════════════════════════════════════
// All functions below are SYNCHRONOUS
// ══════════════════════════════════════════

function getOAuthToken() {
  // 1) Env var
  if (process.env.CLAUDE_CODE_OAUTH_TOKEN) {
    try {
      const env = JSON.parse(process.env.CLAUDE_CODE_OAUTH_TOKEN);
      return env.accessToken || env.claudeAiOauth?.accessToken || null;
    } catch {
      if (process.env.CLAUDE_CODE_OAUTH_TOKEN.startsWith('sk-ant-'))
        return process.env.CLAUDE_CODE_OAUTH_TOKEN;
    }
  }
  // 2) macOS Keychain
  if (process.platform === 'darwin') {
    try {
      const raw = execSync(
        'security find-generic-password -s "Claude Code-credentials" -w 2>/dev/null',
        { encoding: 'utf8', timeout: 2000, stdio: ['pipe', 'pipe', 'pipe'] }
      ).trim();
      if (raw) {
        const c = JSON.parse(raw);
        return c.claudeAiOauth?.accessToken || c.accessToken || null;
      }
    } catch {}
  }
  // 3) Credentials file
  const configDir = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
  try {
    const c = JSON.parse(fs.readFileSync(path.join(configDir, '.credentials.json'), 'utf8'));
    return c.claudeAiOauth?.accessToken || c.accessToken || null;
  } catch {}
  return null;
}

function getLiveUsage() {
  // Fast path: cache hit (~1ms)
  try {
    const cached = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
    if (cached._ts && Date.now() - cached._ts < CACHE_TTL) return cached;
  } catch {}

  // Slow path: curl API (max 2s, happens once every 30s)
  const token = getOAuthToken();
  if (!token) return null;
  try {
    const out = execSync(
      `curl -s --max-time 2 -H "Accept: application/json" -H "Authorization: Bearer ${token}" -H "anthropic-beta: oauth-2025-04-20" "https://api.anthropic.com/api/oauth/usage"`,
      { encoding: 'utf8', timeout: 3000, stdio: ['pipe', 'pipe', 'pipe'] }
    ).trim();
    if (out) {
      const data = JSON.parse(out);
      data._ts = Date.now();
      try { fs.writeFileSync(CACHE_FILE, JSON.stringify(data)); } catch {}
      return data;
    }
  } catch {}

  // Stale cache fallback
  try { return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8')); } catch {}
  return null;
}

// ══════════════════════════════════════════
// Build the statusline string
// ══════════════════════════════════════════

function build(d, live) {
  const model = d.model?.display_name || d.model?.id || '--';
  const ctx = d.context_window || {};
  const cost = d.cost || {};
  const usage = ctx.current_usage || {};

  const inTok = ctx.total_input_tokens || 0;
  const outTok = ctx.total_output_tokens || 0;
  const cacheRead = usage.cache_read_input_tokens || 0;
  const ctxPct = Math.round(ctx.used_percentage || 0);
  const ctxSize = ctx.context_window_size || 200000;
  const costUsd = (cost.total_cost_usd || 0).toFixed(2);

  // ── Rate limits ──
  let fiveHr = null, sevenDay = null;

  if (live && live.five_hour) {
    const p = Math.round(live.five_hour.utilization ?? 0);
    fiveHr = { pct: p, left: 100 - p, reset: live.five_hour.resets_at };
  }
  if (live && live.seven_day) {
    const p = Math.round(live.seven_day.utilization ?? 0);
    sevenDay = { pct: p, left: 100 - p, reset: live.seven_day.resets_at };
  }

  // Fallback to stdin rate limits if no live data
  if (!fiveHr) {
    const rl = d.rate_limits?.five_hour || {};
    let p = rl.used_percentage ?? rl.utilization ?? null;
    if (p != null) {
      p = Number(p);
      if (p > 0 && p <= 1) p *= 100;
      p = Math.round(p);
      if (rl.resets_at) {
        const ts = typeof rl.resets_at === 'string'
          ? Math.floor(new Date(rl.resets_at).getTime() / 1000) : Number(rl.resets_at);
        if (p >= 99 && (ts - Math.floor(Date.now() / 1000)) > 1800) p = null;
      }
      if (p != null) fiveHr = { pct: p, left: 100 - p, reset: rl.resets_at };
    }
  }

  // ── Assemble ──
  const parts = [];

  // Model
  parts.push(`${B}${MG}${model}${R}`);

  // Tokens: ↓in ↑out ⚡cache
  let tok = `${BL}↓${R}${W}${fmt(inTok)}${R} ${CN}↑${R}${W}${fmt(outTok)}${R}`;
  if (cacheRead > 0) tok += ` ${D}⚡${fmt(cacheRead)}${R}`;
  parts.push(tok);

  // Context bar
  const cCol = colorPct(ctxPct);
  parts.push(`${cCol}${bar(ctxPct, 10)}${R} ${cCol}${ctxPct}%${R} ${D}of ${fmt(ctxSize)}${R}`);

  // Cost
  const cc = costUsd < 1 ? G : costUsd < 5 ? Y : RD;
  parts.push(`${cc}$${costUsd}${R}`);

  // 5-hour limit
  if (fiveHr) {
    const rs = fmtReset(fiveHr.reset);
    if (fiveHr.pct >= 100) {
      let s = `${RD}${B}⚠ LIMIT HIT${R} ${RD}${bar(100,8)}${R} ${RD}${B}100%${R} ${D}used out of 5h${R}`;
      if (rs) s += ` ${D}— resets in ${rs}${R}`;
      parts.push(s);
    } else if (fiveHr.pct >= 80) {
      let s = `${RD}${bar(fiveHr.pct,8)}${R} ${RD}${B}${fiveHr.pct}%${R} ${D}used out of 5h${R} ${RD}(${fiveHr.left}% left)${R}`;
      if (rs) s += ` ${D}resets in ${rs}${R}`;
      parts.push(s);
    } else {
      const fc = colorPct(fiveHr.pct);
      let s = `${fc}${bar(fiveHr.pct,8)}${R} ${fc}${fiveHr.pct}%${R} ${D}used out of 5h${R} ${G}(${fiveHr.left}% left)${R}`;
      if (rs) s += ` ${D}resets in ${rs}${R}`;
      parts.push(s);
    }
  }

  // 7-day limit
  if (sevenDay && sevenDay.pct > 0) {
    const sc = colorPct(sevenDay.pct);
    const rs = fmtReset(sevenDay.reset);
    let s = `${D}7d${R} ${sc}${sevenDay.pct}%${R} ${D}used${R} ${sc}(${sevenDay.left}% left)${R}`;
    if (rs) s += ` ${D}resets in ${rs}${R}`;
    parts.push(s);
  }

  // Live dot
  if (live && live._ts) {
    parts.push((Date.now() - live._ts) < 5000 ? `${G}●${R}` : `${D}●${R}`);
  }

  return parts.join(` ${SEP} `) + '\n';
}

function fmt(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(n);
}
function colorPct(p) { return p < 30 ? G : p < 50 ? CN : p < 75 ? Y : RD; }
function bar(p, w) {
  const f = Math.min(Math.round((p / 100) * w), w);
  return '█'.repeat(f) + '░'.repeat(w - f);
}
function fmtReset(r) {
  if (!r) return '';
  const ts = typeof r === 'string' ? Math.floor(new Date(r).getTime() / 1000) : Number(r);
  const d = Math.max(0, ts - Math.floor(Date.now() / 1000));
  if (d <= 0) return 'now';
  const days = Math.floor(d / 86400), h = Math.floor((d % 86400) / 3600), m = Math.floor((d % 3600) / 60);
  if (days > 0) return `${days}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}
