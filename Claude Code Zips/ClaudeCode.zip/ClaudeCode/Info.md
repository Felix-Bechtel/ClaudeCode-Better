# Claude Code Settings Pack — Info

A portable bundle of settings, commands, status line, and plugins for Claude Code.

## Quick Setup

1. Unzip and give `claude-code-setup.md` to a new Claude Code instance
2. Tell it: "Apply the settings from this file"
3. Claude will auto-install the ralph-loop plugin during setup
4. Add your own API key, plugins, and MCP servers to `settings.json` as needed

## What's Included

| File | Description |
|------|-------------|
| `settings.json` | Main config — model, hooks, permissions, status line, effort level |
| `claude-code-setup.md` | Full setup guide with status line script, global instructions, and plugin install |
| `commands/` | Slash commands (see below) |
| `bin/` | Shell scripts for `! status` and `! claudecode-update` |
| `Info.md` | This file |

## Commands

Copy the `commands/` folder to `~/.claude/commands/` to use these as slash commands.

### `/just-do-it`
Skips all confirmation prompts for the rest of the session. Claude will apply every edit, install, and change immediately without asking. Destructive actions still get a brief mention before proceeding.

### `/verify-settings`
Runs a full health check on your Claude Code setup: symlinks, settings.json keys, buddy collection, CLAUDE.md, commands, status line, installed plugins, and zip backups. Reports every check with a pass/fail marker and a final summary.

### `/status`
Quick status overview of your Claude Code setup — plugins, model, permissions, keep-awake, and available commands.

### `/keep-awake`
Turns OFF sleep prevention. Caffeinate runs automatically every session via the statusline — use this command to disable it if you want macOS to sleep normally.

### `/remove-ralph`
Uninstalls the ralph-loop plugin if you don't want it. Just run `/remove-ralph` and it's gone.

## Plugins

### Ralph Loop (`ralph-loop@claude-plugins-official`)
Installed automatically during setup. Enables autonomous development loops — Claude repeatedly works on a task, checks results, and iterates until completion. Great for tasks with clear success criteria like getting tests to pass.

At the start of each new session, Claude will check if a ralph-loop update is available and prompt you to install it.

If you don't want ralph-loop, run `/remove-ralph` to uninstall it.

## Session Start — MANDATORY

At the start of EVERY new conversation, before doing anything else, Claude will:
0. **Auto-update** — silently runs `claudecode-update` to check for new versions from GitHub
1. **"Would you like to use just-do-it? (yes/no)"** — enables no-confirmation mode
2. **"Would you like me to check for Ralph Loop updates? (yes/no)"** — checks for plugin updates

Each prompt is shown one at a time. Claude waits for your answer before showing the next.

## Shell Commands

| Command | Description |
|---------|-------------|
| `! status` | Quick terminal status readout — plugins, model, commands, keep-awake |
| `! claudecode-update` | Manually check for and install updates from ClaudeCode-Better GitHub |

## Settings Highlights

- **Model**: `claude-opus-4-6`
- **Permissions**: bypassPermissions + PermissionRequest hook (auto-approves everything). Cycle with Shift+Tab.
- **Auto-Update**: checks GitHub for new versions at every session start
- **Keep-Awake**: always on via statusline (caffeinate auto-starts)
- **Hooks**: PreCompact (saves context to memory), Stop (save decisions), PermissionRequest (auto-approve all)
- **Status Line**: Token tracker with 5-hour budget, context window bar, effort level, rate limit display
- **Effort Level**: high (shown in statusline footer next to model name)
- **Memory**: Hooks remind Claude to save context before compaction and after each exchange
