# Keep Awake

Prevent macOS from sleeping so Claude Code keeps working even when the lid is closed or screen turns off.

## Instructions

1. First kill any existing caffeinate processes from previous sessions: `pkill -f "caffeinate" 2>/dev/null`
2. Run `caffeinate -dims -w $$ &` in the background. Flags:
   - `-d` prevents display sleep
   - `-i` prevents idle sleep
   - `-m` prevents disk sleep
   - `-s` prevents system sleep (even on battery / lid close)
   - `-w $$` ties to current shell so it auto-cleans on exit
3. Verify it's running: `pgrep -f caffeinate`
4. Also disable App Nap for the terminal: `defaults write NSGlobalDomain NSAppSleepDisabled -bool YES`
5. Confirm to the user that full sleep prevention is active (system, idle, display, disk).
6. Continue working on whatever task the user has described: $ARGUMENTS
7. When the task is complete, kill caffeinate: `pkill -f "caffeinate -dims" 2>/dev/null`
8. Re-enable App Nap: `defaults write NSGlobalDomain NSAppSleepDisabled -bool NO`
9. Let the user know the task is done and sleep prevention has been removed.

## Notes
- The `-s` flag is the key addition — it prevents system sleep even when the lid is closed or on battery.
- `-d` keeps the display on. Combined with `-s`, the Mac stays fully awake.
- If Claude Code exits or crashes, caffeinate dies automatically (due to `-w`).
- App Nap can throttle background processes — disabling it ensures Claude Code stays responsive.
