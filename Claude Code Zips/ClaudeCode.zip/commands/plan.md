---
description: Switch the Claude plan token budget shown in the statusline footer
argument-hint: [pro|5x|20x|auto]
---

Run the `plan` shell command to switch the Claude plan that drives the footer's token budget.

The available plans are:
- **Pro** — 44k tokens / 5h
- **Max 5x** — 88k tokens / 5h
- **Max 20x** — 220k tokens / 5h
- **auto** — clear the override and auto-detect from the macOS Keychain rate-limit tier

If the user passed an argument (`pro`, `5x`, `20x`, or `auto`), execute:

```bash
plan $ARGUMENTS
```

If the user did NOT pass an argument, run `plan` with no args to show the menu, then ask them which plan to set.

After the command runs, the footer refreshes on the next status tick (~1s). The script also invalidates `${TMPDIR}/token-tracker-usage.json` so a fresh API call happens immediately.
