---
description: Switch the Claude plan token budget shown in the statusline footer
argument-hint: [1|2|3|4 | pro|5x|20x|auto]
---

Run the `plan` shell command to switch the Claude plan that drives the footer's token budget.

The available plans (numbered for fast typing):
- **1** = `pro` — Pro · 44k tokens / 5h
- **2** = `5x`  — Max 5x · 88k tokens / 5h
- **3** = `20x` — Max 20x · 220k tokens / 5h
- **4** = `auto` — clear the override and auto-detect from the macOS Keychain rate-limit tier

If the user passed an argument (a number `1`–`4`, or one of `pro`/`5x`/`20x`/`auto`), execute:

```bash
plan $ARGUMENTS
```

If the user did NOT pass an argument, run `plan` with no args to show the menu, then ask them which plan to set.

After the command runs, the footer refreshes on the next status tick (~1s). The script also invalidates `${TMPDIR}/token-tracker-usage.json` so a fresh API call happens immediately.
