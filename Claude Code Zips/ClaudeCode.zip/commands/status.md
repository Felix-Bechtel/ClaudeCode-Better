# Status

Show a quick status overview of the current Claude Code setup.

## Instructions

1. Run `claude plugins list 2>/dev/null` and report installed plugins
2. Check if `~/.claude/settings.json` exists and report the model and permission mode
3. Run `python3 ~/.claude/statusline.py < /dev/null 2>/dev/null` — if it errors, note statusline may need live session data
4. Check if caffeinate is running: `pgrep -f caffeinate >/dev/null 2>&1` — report keep-awake status
5. Report which slash commands are available by listing `~/.claude/commands/`
6. If $ARGUMENTS is provided, also check whatever the user specifies

Keep the output short — one line per item, with a status marker.
