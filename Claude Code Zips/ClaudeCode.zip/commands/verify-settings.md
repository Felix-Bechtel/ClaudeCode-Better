# Verify Claude Code Settings

Run a full verification of all Claude Code settings, symlinks, configs, and zips after any update. Report results with ✓/✗ markers.

## Tests to Run

### 1. Symlinks
Check that each of these symlinks in `~/.claude/` exists and points to a valid target:
- `settings.json`
- `statusline.py`
- `statusline.js`
- `CLAUDE.md`

Also check that these regular files exist (NOT symlinks):
- `buddy-collection.json` — user data file, auto-created by buddy.js

### 2. settings.json
- Parse as valid JSON
- Confirm these keys exist and have values: `statusLine`, `hooks`, `permissions.defaultMode`, `effortLevel`, `statusLineExtendedDisplay`, `statusLineTokenBudget`, `statusLineContextWindow`, `statusLineDailyTokenMode`
- List enabled plugins and MCP servers

### 3. buddy-collection.json
- Parse as valid JSON
- Report active buddy and total buddy count

### 4. CLAUDE.md
- Confirm it contains the "Session Start" section with the just-do-it prompt

### 5. Commands
- List all files in `~/.claude/commands/` and confirm each is readable

### 6. Statusline
- Pipe test JSON into `~/.claude/statusline.py` and confirm it produces output without errors

### 7. Plugins
- Run `claude plugins list` and report installed plugins and their status

### 8. ClaudeCode.zip
- Extract to a temp dir
- Validate `settings.json` has all footer/statusline keys
- Confirm `commands/` folder and all command files are present

### 9. buddy-system.zip
- Extract to a temp dir and confirm it extracts without errors

### 10. Summary
Print a final summary line: total checks passed / total checks run.

## Notes
- Use a temp directory for zip extraction and clean up after.
- If $ARGUMENTS is provided, also test whatever the user specifies.
- If any test fails, explain what's wrong and offer to fix it.