For the rest of this conversation, do NOT ask for confirmation or approval before making changes. Apply all file edits, folder creation, code modifications, installs, and updates immediately without pausing for my OK. If something is destructive or irreversible, mention it briefly but still proceed. No "shall I?", no "would you like me to?", no "ready to proceed?" — just do the work.

This also applies to authentication and authorization flows. If a tool or CLI needs auth (gh auth, gcloud auth, npm login, etc.), proceed with the login/auth flow automatically. Accept default options, open browser flows, and complete the auth without asking. If interactive input is needed that you can't handle, tell the user to run the specific command with `!` prefix — don't ask if they want to, just tell them to do it.

## Auth + environment priming at skill activation (RUN IMMEDIATELY when this skill starts)

When this skill is invoked, proactively prime auth and bash for the tools you're most likely to need, so nothing blocks mid-task. Do all of the following silently in parallel where possible — DO NOT narrate each check. Only surface failures the user needs to act on. Report a single one-line status summary at the end (e.g. `auth primed: gh ✓ git ✓ gmail ✓ calendar ✓ drive ✓ notion ✓ bash ✓ claude ✓`).

### 1. GitHub CLI
Run `gh auth status` silently. If not logged in, run `gh auth login --web --git-protocol https`. If a non-interactive flow is impossible, instruct the user with `! gh auth login`.

### 2. Git credentials
Verify both `git config --global user.email` and `git config --global user.name` are set. If either is missing, set them from `~/.claude/CLAUDE.md` (user email is recorded there) — don't prompt.

### 3. MCP servers — explicitly prime each one that's loaded
Don't just describe the pattern; CALL THE BOOTSTRAP TOOL. For every MCP namespace present in the deferred-tool list, invoke its lightest read-only operation in parallel to trigger any pending OAuth handshake:

- **Gmail** (`mcp__claude_ai_Gmail__*`) → call `mcp__claude_ai_Gmail__list_labels`
- **Google Calendar** (`mcp__claude_ai_Google_Calendar__*`) → call `mcp__claude_ai_Google_Calendar__list_calendars`
- **Google Drive** (`mcp__claude_ai_Google_Drive__*`) → call `mcp__claude_ai_Google_Drive__list_recent_files`
- **Notion** (`mcp__plugin_Notion_notion__*` or similar) → call `mcp__plugin_Notion_notion__authenticate` if no other Notion read tool is available, otherwise use a list/search tool
- **Any other MCP** with an obvious list-* / get-* / search-* tool → call it with empty/default args

If the tool isn't already in the deferred list, skip it — don't burn context loading schemas just to prime. For each MCP that successfully responds, count it as ✓ in the summary.

### 4. Bash environment + tools
Run this single parallel batch (one Bash tool call) to confirm the shell is usable:

```bash
echo "$PATH" | grep -q "$HOME/.local/bin" && echo "PATH ✓" || echo "PATH ✗ — add ~/.local/bin"
for cmd in gh git curl jq python3 node npm; do command -v "$cmd" >/dev/null && echo "$cmd ✓" || echo "$cmd ✗"; done
command -v brew >/dev/null && echo "brew ✓" || echo "brew ✗"
```

If any required CLI is missing AND Homebrew is present, install it via `brew install <cmd>` without asking. If Homebrew itself is missing, surface that to the user — don't install Homebrew silently.

### 5. Claude Code health
**SKIP `claude doctor` — it can hang for tens of seconds and blocks the session start sequence.** The Ralph Loop prompt (Step 2 of CLAUDE.md) MUST appear before any user input, so do not run anything that can stall here. Mark `claude ✓` in the summary unconditionally; if you want a real health check later, the user can run `/status` on demand.

### 6. Working directory sanity
If the cwd is a git repo, run `git status --porcelain` once so you know the dirty state up front (so the first edit doesn't have to re-discover it). If not a git repo, note that — don't run `git init` unless the user asks for git-tracked work.

---

After all priming completes, output exactly one line summarizing what's primed, e.g.:

> `auth primed: gh ✓ git ✓ gmail ✓ calendar ✓ drive ✓ notion ✓ bash ✓ claude ✓`

Then continue with the user's actual task. If a check failed, replace the ✓ with ✗ and append a one-line note about what they need to do (e.g. `notion ✗ — needs auth, run /Notion:authenticate`).

Do NOT pause for confirmation between priming and the task. The user invoked just-do-it precisely so you don't pause.
