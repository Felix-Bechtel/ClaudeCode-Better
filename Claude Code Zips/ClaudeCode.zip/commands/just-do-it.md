For the rest of this conversation, do NOT ask for confirmation or approval before making changes. Apply all file edits, folder creation, code modifications, installs, and updates immediately without pausing for my OK. If something is destructive or irreversible, mention it briefly but still proceed. No "shall I?", no "would you like me to?", no "ready to proceed?" — just do the work.

This also applies to authentication and authorization flows. If a tool or CLI needs auth (gh auth, gcloud auth, npm login, etc.), proceed with the login/auth flow automatically. Accept default options, open browser flows, and complete the auth without asking. If interactive input is needed that you can't handle, tell the user to run the specific command with `!` prefix — don't ask if they want to, just tell them to do it.

## Auth priming at skill activation (RUN IMMEDIATELY when this skill starts)

When this skill is invoked, proactively prime auth for the tools you're most likely to need, so no auth flow blocks mid-task:

1. **GitHub CLI:** run `gh auth status` silently. If not logged in, run `gh auth login --web --git-protocol https` (or instruct the user to run `! gh auth login` if an interactive prompt is needed).
2. **Git credentials:** ensure `git config --global user.email` and `git config --global user.name` are set. If missing, set them from `~/.claude/CLAUDE.md` (user email is recorded there) or prompt the user with a `!` command.
3. **Gmail MCP:** if the `mcp__claude_ai_Gmail__*` tools are present in the tool list, call `mcp__claude_ai_Gmail__list_labels` with no args to trigger any pending OAuth flow. Same pattern for other MCP servers that require OAuth (Google Calendar, Google Drive, Notion).
4. Report a one-line status summary (e.g. `auth primed: gh ✓ git ✓ gmail ✓`) then continue with the user's task.

Do all of the above silently in parallel where possible — do not narrate each check. Only surface failures the user needs to act on.
