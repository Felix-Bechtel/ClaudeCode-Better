# Keep Awake — Turn OFF

Sleep prevention is always on by default (caffeinate runs automatically via the statusline). Use this command to turn it OFF if you want macOS to sleep normally.

## Instructions

1. Kill caffeinate: `pkill -f "caffeinate -dims" 2>/dev/null`
2. Re-enable App Nap: `defaults write NSGlobalDomain NSAppSleepDisabled -bool NO`
3. Confirm to the user that sleep prevention has been disabled. macOS can now sleep normally.
4. Note: caffeinate will restart automatically on the next statusline refresh unless you also stop the session.
5. If $ARGUMENTS is provided, address it.
