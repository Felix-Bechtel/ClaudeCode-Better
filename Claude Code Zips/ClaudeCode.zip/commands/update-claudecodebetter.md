Update the ClaudeCode-Better settings pack AND Claude Code itself, then restart so the updates take effect.

Run these steps in order. Do NOT ask for confirmation — just execute.

## Step 1: Save conversation memory

Before anything else, save any important decisions, findings, or non-obvious context from the current chat to memory files under `~/.claude/projects/-Users-felixbechtel-Projects-<current-project>/memory/`. Update `MEMORY.md` accordingly. If nothing non-obvious happened this session, skip — don't invent memories.

## Step 2: Update the ClaudeCode-Better settings pack

Run this in Bash. It is fast (network-bounded with built-in 15s/90s timeouts) and CANNOT freeze the session:

```bash
claudecode-update --yes
```

Show the output. If it reports "up to date," tell the user nothing was installed for the settings pack — then continue to Step 3.

If it installed an update and `~/ClaudeCode-Better` exists as a git checkout, briefly summarize what changed:

```bash
[ -d "$HOME/ClaudeCode-Better/.git" ] && git -C "$HOME/ClaudeCode-Better" log --oneline -3 || true
```

## Step 3: Update Claude Code itself — DO NOT run from inside this session

⚠️ **Important:** `claude update` and `npm install -g @anthropic-ai/claude-code@latest` are NOT safe to run from inside the currently-running Claude Code session. They hang because:

- `claude update` cannot replace the running binary that's hosting this conversation.
- `npm install -g` against `/opt/homebrew` frequently hangs on permission prompts or slow registry, with no stdin to answer it.

So **do not run them in this session**. Instead, give the user a single copy-pasteable command to run AFTER they exit:

> Run this in a fresh terminal after closing this session:
>
> ```bash
> claude update 2>/dev/null || /Users/felixbechtel/.local/bin/claude update 2>/dev/null || /opt/homebrew/bin/claude update; claude --version
> ```
>
> (npm-installed copy, optional — only if you originally installed via npm:)
>
> ```bash
> npm install -g @anthropic-ai/claude-code@latest
> ```

## Step 4: End this session so the new files load

The settings.json, CLAUDE.md, commands/, hooks, AND the new Claude Code binary only take effect in a fresh Claude Code session. Tell the user — in exactly this wording:

> **✅ Settings pack installed. Claude Code itself must be updated AFTER you exit (running `claude update` from inside this session would freeze it).**
>
> 1. Close this session: Ctrl+D, or type `/exit`
> 2. In your terminal run: `claude update && claude --version`
> 3. Start a fresh session: `claude`
>
> Everything new will load on first prompt.

Do NOT try to kill the process yourself — Claude Code cannot safely self-terminate.
