Update the ClaudeCode-Better settings pack AND Claude Code itself, then restart so the updates take effect.

Run these steps in order. Do NOT ask for confirmation — just execute.

## Step 1: Save conversation memory

Before anything else, save any important decisions, findings, or non-obvious context from the current chat to memory files under `~/.claude/projects/-Users-felixbechtel-Projects-<current-project>/memory/`. Update `MEMORY.md` accordingly. If nothing non-obvious happened this session, skip — don't invent memories.

## Step 2: Update the ClaudeCode-Better settings pack

Run this in Bash:

```bash
claudecode-update --yes
```

Show the output. If it reports "up to date," the remote SHA already matches local — tell the user nothing was installed for the settings pack, then continue to Step 3 anyway (Claude Code itself may still need an update).

If it installed an update, briefly summarize what changed:

```bash
cd ~/ClaudeCode-Better && git log --oneline -3
```

## Step 3: Update Claude Code itself

Run this in Bash:

```bash
claude update 2>/dev/null || /Users/felixbechtel/.local/bin/claude update 2>/dev/null || /opt/homebrew/bin/claude update
```

This uses Claude Code's built-in auto-updater (covers the native installer at `~/.local/bin/claude` and the npm/homebrew install at `/opt/homebrew/bin/claude`). Show the output. If it reports already on the latest version, that's fine — continue to Step 4.

Also bump the npm-installed copy (no-op if not installed that way):

```bash
npm install -g @anthropic-ai/claude-code@latest 2>/dev/null || true
```

Print the new version so the user sees what's now installed:

```bash
claude --version
```

## Step 4: End this session so the new files load

The settings.json, CLAUDE.md, commands/, hooks, AND the new Claude Code binary only take effect in a fresh Claude Code session. Tell the user — in exactly this wording:

> **✅ Updates installed (settings pack + Claude Code itself). This session has the OLD config + binary loaded.**
>
> To activate the new versions, close this session (Ctrl+D, or type `/exit`) and start a fresh one with `claude`. Everything new will load on first prompt.

Do NOT try to kill the process yourself — Claude Code cannot safely self-terminate. The user ends the session; the next `claude` invocation picks up the new files.
