Update the ClaudeCode-Better settings pack and restart so the update takes effect.

Run these steps in order. Do NOT ask for confirmation — just execute.

## Step 1: Save conversation memory

Before anything else, save any important decisions, findings, or non-obvious context from the current chat to memory files under `~/.claude/projects/-Users-felixbechtel-Projects-<current-project>/memory/`. Update `MEMORY.md` accordingly. If nothing non-obvious happened this session, skip — don't invent memories.

## Step 2: Install the update

Run this in Bash:

```bash
claudecode-update --yes
```

Show the output. If it reports "up to date," the remote SHA already matches local and there's nothing to install — tell the user and stop.

If it installed an update, briefly summarize what changed by running:

```bash
cd ~/ClaudeCode-Better && git log --oneline -3
```

## Step 3: End this session so the new files load

The settings.json, CLAUDE.md, commands/, and hooks in the update only take effect in a fresh Claude Code session. Tell the user — in exactly this wording:

> **✅ Update installed. This session has the OLD config loaded.**
>
> To activate the new files, close this session (Ctrl+D, or type `/exit`) and start a fresh one with `claude`. The new config will load on first prompt.

Do NOT try to kill the process yourself — Claude Code cannot safely self-terminate. The user ends the session; the next `claude` invocation picks up the new files.
