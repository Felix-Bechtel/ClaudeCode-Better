# Remove Ralph Loop

Uninstall the ralph-loop plugin from Claude Code.

## Instructions

1. Run `claude plugins uninstall ralph-loop@claude-plugins-official`
2. Confirm to the user that ralph-loop has been removed.
3. If $ARGUMENTS contains additional context, address it.