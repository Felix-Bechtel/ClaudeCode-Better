# Starter templates

These are the "empty setup" files the installer scaffolds onto a fresh machine so
Claude Code's memory system works out of the box.

| File | What it becomes after install |
|------|-------------------------------|
| `memory/MEMORY.md` | Your persistent memory **index**, seeded into `~/.claude/projects/<your-home-project>/memory/MEMORY.md` (only if you don't already have one) |
| `memory/example-user-profile.md.sample` | A sample memory file showing the frontmatter format — rename or delete it |
| `CLAUDE.md.template` | A blank per-project `CLAUDE.md` you can copy into any repo |

`install.sh` copies these only when the destination is missing, so your existing
memories are never overwritten.
