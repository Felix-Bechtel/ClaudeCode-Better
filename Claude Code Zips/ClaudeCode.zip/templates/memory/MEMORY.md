<!--
This is your persistent memory INDEX. Claude Code loads this file at the start of
every session. Add ONE line per memory file below so Claude knows what it can recall.

Format:  - [Title](file-name.md) — short hook describing the memory

Each memory is its own .md file in this folder with frontmatter:

  ---
  name: <short-kebab-case-slug>
  description: <one-line summary — used to decide relevance during recall>
  metadata:
    type: user | feedback | project | reference
  ---

  <the fact. Link related memories with [[their-name]].>

Keep entries minimal (under ~100 chars). Update existing files instead of
duplicating. Delete memories that turn out to be wrong.
-->

# Memory Index

<!-- Your saved memories will be listed here. It's empty for now — Claude fills it in as you work. -->
