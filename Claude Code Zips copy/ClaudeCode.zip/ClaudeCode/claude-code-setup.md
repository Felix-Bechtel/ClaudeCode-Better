# Claude Code Setup Guide

Give this file to a new Claude Code instance and ask it to apply these settings.

---

## How to Apply

Tell the new Claude Code instance:

> Apply the settings from this file — write `settings.json` to `~/.claude/settings.json`, save the statusline script to `~/.claude/statusline.py`, and update `~/.claude/CLAUDE.md`.

> Note: Add your own `env.ANTHROPIC_API_KEY`, `enabledPlugins`, and `mcpServers` to `settings.json` as needed — those are account/machine-specific.

---

## 1. Settings

Save `settings.json` to `~/.claude/settings.json`.

---

## 2. Status Line Script (`~/.claude/statusline.py`)

Save the following as `~/.claude/statusline.py`:

```python
#!/usr/bin/env python3
"""token-tracker v6 — event-based stdin + sync API via curl (Python port)
No async. Fast cache reads, 2s max curl on cache miss.
"""

import json
import os
import sys
import subprocess
import time
from pathlib import Path

# ── Colors ──
R = '\x1b[0m'; B = '\x1b[1m'; D = '\x1b[2m'
W = '\x1b[97m'; CN = '\x1b[36m'; G = '\x1b[32m'
Y = '\x1b[33m'; RD = '\x1b[91m'; MG = '\x1b[35m'
BL = '\x1b[34m'; GY = '\x1b[90m'
SEP = f'{GY}\u2502{R}'

# ── Cache ──
CACHE_FILE = Path(os.environ.get('TMPDIR', '/tmp')) / 'token-tracker-usage.json'
CACHE_TTL = 5


def get_oauth_token():
    # 1) Env var
    env_tok = os.environ.get('CLAUDE_CODE_OAUTH_TOKEN')
    if env_tok:
        try:
            env = json.loads(env_tok)
            return env.get('accessToken') or (env.get('claudeAiOauth') or {}).get('accessToken')
        except (json.JSONDecodeError, TypeError):
            if env_tok.startswith('sk-ant-'):
                return env_tok
    # 2) macOS Keychain
    if sys.platform == 'darwin':
        try:
            raw = subprocess.run(
                ['security', 'find-generic-password', '-s', 'Claude Code-credentials', '-w'],
                capture_output=True, text=True, timeout=2
            ).stdout.strip()
            if raw:
                c = json.loads(raw)
                return (c.get('claudeAiOauth') or {}).get('accessToken') or c.get('accessToken')
        except Exception:
            pass
    # 3) Credentials file
    config_dir = Path(os.environ.get('CLAUDE_CONFIG_DIR', Path.home() / '.claude'))
    try:
        c = json.loads((config_dir / '.credentials.json').read_text())
        return (c.get('claudeAiOauth') or {}).get('accessToken') or c.get('accessToken')
    except Exception:
        pass
    return None


def get_live_usage():
    # Fast path: cache hit
    try:
        cached = json.loads(CACHE_FILE.read_text())
        if cached.get('_ts') and time.time() - cached['_ts'] < CACHE_TTL:
            return cached
    except Exception:
        pass

    # Slow path: curl API (max 2s)
    token = get_oauth_token()
    if not token:
        return None
    try:
        result = subprocess.run(
            ['curl', '-s', '--max-time', '2',
             '-H', 'Accept: application/json',
             '-H', f'Authorization: Bearer {token}',
             '-H', 'anthropic-beta: oauth-2025-04-20',
             'https://api.anthropic.com/api/oauth/usage'],
            capture_output=True, text=True, timeout=3
        )
        out = result.stdout.strip()
        if out:
            data = json.loads(out)
            data['_ts'] = time.time()
            try:
                CACHE_FILE.write_text(json.dumps(data))
            except Exception:
                pass
            return data
    except Exception:
        pass

    # Stale cache fallback
    try:
        return json.loads(CACHE_FILE.read_text())
    except Exception:
        pass
    return None


def fmt(n):
    if n >= 1e6:
        return f'{n/1e6:.1f}M'
    if n >= 1e3:
        return f'{n/1e3:.1f}k'
    return str(n)


def color_pct(p):
    if p < 30: return G
    if p < 50: return CN
    if p < 75: return Y
    return RD


def bar(p, w=10):
    f = min(round(p / 100 * w), w)
    return '\u2588' * f + '\u2591' * (w - f)


def fmt_reset(r):
    if not r:
        return ''
    if isinstance(r, str):
        from datetime import datetime
        try:
            ts = int(datetime.fromisoformat(r.replace('Z', '+00:00')).timestamp())
        except Exception:
            return ''
    else:
        ts = int(r)
    d = max(0, ts - int(time.time()))
    if d <= 0:
        return 'now'
    days = d // 86400
    h = (d % 86400) // 3600
    m = (d % 3600) // 60
    if days > 0:
        return f'{days}d {h}h'
    if h > 0:
        return f'{h}h {m}m'
    return f'{m}m'


def build(d, live):
    model = (d.get('model') or {}).get('display_name') or (d.get('model') or {}).get('id') or '--'
    ctx = d.get('context_window') or {}
    cost = d.get('cost') or {}
    usage = ctx.get('current_usage') or {}

    in_tok = ctx.get('total_input_tokens') or 0
    out_tok = ctx.get('total_output_tokens') or 0
    cache_read = usage.get('cache_read_input_tokens') or 0
    ctx_pct = round(ctx.get('used_percentage') or 0)
    ctx_size = ctx.get('context_window_size') or 200000
    cost_usd = cost.get('total_cost_usd') or 0

    # ── Rate limits ──
    five_hr = None
    seven_day = None

    if live and live.get('five_hour'):
        p = round(live['five_hour'].get('utilization') or 0)
        five_hr = {'pct': p, 'left': 100 - p, 'reset': live['five_hour'].get('resets_at')}
    if live and live.get('seven_day'):
        p = round(live['seven_day'].get('utilization') or 0)
        seven_day = {'pct': p, 'left': 100 - p, 'reset': live['seven_day'].get('resets_at')}

    # Fallback to stdin rate limits
    if not five_hr:
        rl = (d.get('rate_limits') or {}).get('five_hour') or {}
        p = rl.get('used_percentage') or rl.get('utilization')
        if p is not None:
            p = float(p)
            if 0 < p <= 1:
                p *= 100
            p = round(p)
            if rl.get('resets_at'):
                if isinstance(rl['resets_at'], str):
                    from datetime import datetime
                    try:
                        ts = int(datetime.fromisoformat(rl['resets_at'].replace('Z', '+00:00')).timestamp())
                    except Exception:
                        ts = 0
                else:
                    ts = int(rl['resets_at'])
                if p >= 99 and (ts - int(time.time())) > 1800:
                    p = None
            if p is not None:
                five_hr = {'pct': p, 'left': 100 - p, 'reset': rl.get('resets_at')}

    # ── Assemble ──
    parts = []

    # Model
    parts.append(f'{B}{MG}{model}{R}')

    # Tokens
    tok = f'{BL}\u2193{R}{W}{fmt(in_tok)}{R} {CN}\u2191{R}{W}{fmt(out_tok)}{R}'
    if cache_read > 0:
        tok += f' {D}\u26a1{fmt(cache_read)}{R}'
    parts.append(tok)

    # Context bar
    c_col = color_pct(ctx_pct)
    parts.append(f'{c_col}{bar(ctx_pct, 10)}{R} {c_col}{ctx_pct}%{R} {D}of {fmt(ctx_size)}{R}')

    # 5h token budget (44k max)
    five_hr_pct = five_hr['pct'] if five_hr else 0
    used_5h = round(44000 * five_hr_pct / 100)
    left_5h = 44000 - used_5h
    tc = color_pct(five_hr_pct)
    parts.append(f'{tc}{fmt(used_5h)}{R}{D}/{R}{W}{fmt(44000)}{R} {D}tokens{R}')

    # 5-hour limit
    if five_hr:
        rs = fmt_reset(five_hr['reset'])
        if five_hr['pct'] >= 100:
            s = f'{RD}{B}\u26a0 LIMIT HIT{R} {RD}{bar(100, 8)}{R} {RD}{B}100%{R} {D}used out of 5h{R}'
            if rs:
                s += f' {D}\u2014 resets in {rs}{R}'
            parts.append(s)
        elif five_hr['pct'] >= 80:
            s = f'{RD}{bar(five_hr["pct"], 8)}{R} {RD}{B}{five_hr["pct"]}%{R} {D}used out of 5h{R} {RD}({five_hr["left"]}% left){R}'
            if rs:
                s += f' {D}resets in {rs}{R}'
            parts.append(s)
        else:
            fc = color_pct(five_hr['pct'])
            s = f'{fc}{bar(five_hr["pct"], 8)}{R} {fc}{five_hr["pct"]}%{R} {D}used out of 5h{R} {G}({five_hr["left"]}% left){R}'
            if rs:
                s += f' {D}resets in {rs}{R}'
            parts.append(s)

    # Live dot
    if live and live.get('_ts'):
        dot = f'{G}\u25cf{R}' if (time.time() - live['_ts']) < 5 else f'{D}\u25cf{R}'
        parts.append(dot)

    return f' {SEP} '.join(parts) + '\n'


def main():
    data = sys.stdin.read()
    try:
        session = json.loads(data)
        live = get_live_usage()
        sys.stdout.write(build(session, live))
    except Exception:
        sys.stdout.write(f'{D}token-tracker: waiting\u2026{R}\n')


if __name__ == '__main__':
    main()
```

---

## 3. Global Instructions (`~/.claude/CLAUDE.md`)

```markdown
# User Preferences
- Keep responses concise and actionable.
- Prefer running commands directly when asked.
- Default model preference: `claude-opus-4-6-extended`.
- Permission preference: bypass permissions mode in trusted local environments.

## Working Style
- Confirm critical changes briefly, then do the work.
- For setup tasks, prefer one-time automatic setup where possible.
```

---

## Status Line Display

The status line shows: model name · input/output tokens · context window % · tokens used out of 44k 5-hour budget · 5-hour limit bar with percentage and reset countdown · live API indicator dot.

---

## 4. Plugins

After applying settings, install the ralph-loop plugin:

```
claude plugins install ralph-loop@claude-plugins-official
```

This enables autonomous development loops — Claude repeatedly works on a task until completion.

---

## 5. Commands

Copy all `.md` files from the `commands/` folder to `~/.claude/commands/`. This gives you:

- `/just-do-it` — Skip all confirmation prompts
- `/verify-settings` — Full health check of your Claude Code setup
- `/keep-awake` — Prevent macOS sleep during long tasks
- `/remove-ralph` — Uninstall ralph-loop if you don't want it
