# Keep Awake

Prevent macOS from sleeping so Claude Code can keep working even when the screen turns off.

## Instructions

1. Run `caffeinate -i -w $$` in the background. This prevents idle sleep while allowing the display to turn off. The `-w $$` flag ties it to the current shell process so it auto-cleans up.
2. Confirm to the user that sleep prevention is active.
3. Continue working on whatever task the user has described: $ARGUMENTS
4. When the task is complete, kill the caffeinate process (`pkill -f "caffeinate -i -w"` scoped to this session).
5. Let the user know the task is done and sleep prevention has been removed.

## Notes
- This does NOT prevent the display from dimming/turning off — only prevents the Mac from going to full system sleep.
- If Claude Code exits or crashes, caffeinate dies automatically (due to `-w`).
